# PSP EBOOT: Building for Official Firmware & Paranoid Cross-Validation

A complete engineering guide and executable laboratory for a small user-mode
PSP application. The separately delivered PDF embeds this exact source-and-tests
ZIP. It contains11 engineering chapters, the full example and evidence tables.
The external TECHNICAL_AUDIT.md records final document/package review.

## Start here

Verify the external SHA256SUMS.txt before extraction. The internal manifest
hashes every other ZIP member. It cannot hash itself; the package is externally
hashed, and its manifest's individual hash is recorded in the external audit.

- `packages/SampleApp-Install.zip`: fresh installation archive, root instructions,
  license, validation, notices and PSP/GAME/SampleApp/EBOOT.PBP.
- `sample/`: the exact compiled main.c and Makefile printed in the PDF.
- `pspguide/`, `tools/`, `tests/`: bounded parsers, safe signer, separate PyCA
  crypto verifier, scoped NID auditor, fresh packager and actual tests.
- `REPRODUCE.md`, `document/lab-commands.md`: host/container/build/sign/test steps.
- `artifacts/build-a`, `artifacts/build-b`: actual ELF, PRX, SFO, unsigned/signed
  PBP and link maps. Signed PBP is installed as EBOOT.PBP.
- `environment/`, `references/`: package locks, image/tool/library identities,
  pinned source archives/files and public-user-stub NID mapping.
- `evidence/`: actual test logs, reports, negative-control reconstruction details,
  both review findings and their closure, PPSSPP runs and preserved failures.
- `research/`: exact source revisions, hardware/specification qualifications,
  signing-tool comparison and component notice observations.
- `document/`: complete prose, embedded-font notices and PDF/render tooling.

## Results and limits

Final host suite38/38PASS;13 actual-artifact negative CLI controlsPASS; two
independent build directories produced identical ELF/PRX/unsignedPBP/signedPBP
(and SFO); isolated signing and separate verificationPASS. Six PPSSPP1.20.4
cold direct launches demonstrated readiness, advancing heartbeat and CROSS
exit through ExitGame/game.quit. All original earlier FAIL/ERROR evidence is
retained and explained. This is not an uninterrupted green run.

**Physical stock OFW6.60/6.61 on all five PSP families: NOT TESTED.** Physical
XMB discovery, HOME callback and suspend/resume: NOT TESTED. Physical peak RAM,
CPU/FPS and sustained performance: NOT MEASURED. SDK mapping is not a census of
permitted exports on target firmware. Unknown properties remain UNKNOWN.

Signed EBOOT SHA256:
`d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47`

Install only the identified signed file; the unsigned intermediate is for audit.
The install README gives the resulting PSP/GAME/SampleApp/EBOOT.PBP path.
Directory1..32ASCII bytes is publisher policy, not a verified Sony limit.
No card was modified by this laboratory. No Sony firmware or user music is
included. External legacy sources/executables and PPSSPP are fetched separately.

Read LICENSE.txt, THIRD_PARTY_NOTICES.md and licenses/ for component scopes.
The own-source MIT grant does not clear legacy templates or certify OFW launch.
