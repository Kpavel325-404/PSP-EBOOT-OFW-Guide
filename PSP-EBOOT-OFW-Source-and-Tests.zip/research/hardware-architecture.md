# Verified hardware and firmware architecture notes

Research scope: PSP EBOOT / OFW Community Guide only. Retrieved 2026-10-29. This is source research, not a device test. No hardware, stock-firmware launch, audio, storage, HOLD, or module result was obtained in this task.

## Evidence boundaries

Sony manufacturer releases establish the advertised physical hardware. PSPSDK source establishes what that community SDK declares and builds. Neither source category establishes that this guide's EBOOT is accepted by a particular stock firmware, that a given import can be resolved there, or that a module can be loaded in the application's privilege context. Record those outcomes separately.

All PSPSDK references below are pinned to commit `6ef2b21dc440ef8d4125f000301faaa2a470975e`. The SDK is an open-source project; its headers are not Sony's proprietary SDK and are not a stock-firmware conformance certificate. [SDK README](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/README.md)

## Hardware families and memory

The "MB" and "GB" labels below preserve Sony's units. They describe installed main memory or storage, not an application's allocatable heap. Do not silently replace them with a measured byte count.

| Family | Sony physical main memory | Sony total embedded DRAM | GE VRAM accessible in the guide's run | Application free memory / largest free block | Guide on stock OFW |
| --- | --- | --- | --- | --- | --- |
| PSP-1000 | 32 MB [H1] | 4 MB [H1] | UNKNOWN; NOT TESTED | UNKNOWN; NOT TESTED | NOT TESTED |
| PSP-2000 | 64 MB [H2] | UNKNOWN in cited release | UNKNOWN; NOT TESTED | UNKNOWN; NOT TESTED | NOT TESTED |
| PSP-3000 | 64 MB [H3] | UNKNOWN in cited release | UNKNOWN; NOT TESTED | UNKNOWN; NOT TESTED | NOT TESTED |
| PSP Go / PSP-N1000 | 64 MB [H4] | UNKNOWN in cited release | UNKNOWN; NOT TESTED | UNKNOWN; NOT TESTED | NOT TESTED |
| PSP Street / PSP-E1000 | 64 MB [H5] | UNKNOWN in cited release | UNKNOWN; NOT TESTED | UNKNOWN; NOT TESTED | NOT TESTED |

H1's 4 MB is explicitly **total embedded DRAM**. The release does not identify that whole amount as application-accessible GE VRAM. A table that calls it "4 MB VRAM" would exceed the evidence.

The pinned `pspge.h` documents `sceGeEdramGetSize()` as returning VRAM size in bytes. It does **not** document a fixed 2 MiB return for every family or run. Its separate setter documents the byte values `0x200000` and `0x400000` (2 MiB and 4 MiB) and an error for the larger value on "PSP FAT." These setter parameters are not measured capacities, default enabled sizes, or evidence that calling the setter is permitted on every OFW. [H7, lines 69–90](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/ge/pspge.h#L69)

For the memory budget, keep four different quantities: installed main RAM, total embedded DRAM, enabled GE VRAM, and the memory actually available to the running application. PSPSDK documents `sceKernelTotalFreeMemSize()` and `sceKernelMaxFreeMemSize()` as separate byte-valued queries. Log both at defined checkpoints when those imports are supported; a total-free figure alone does not show whether one contiguous allocation can succeed. Do not invent universal "24 MB usable" or "56 MB usable" results from physical RAM totals. [H8, lines 45–104](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/user/pspsysmem.h#L45)

## Family differences that affect installation and runtime assumptions

| Family | Source-established differences relevant to this guide | Engineering consequence | Stock-OFW result |
| --- | --- | --- | --- |
| PSP-1000 | UMD; Memory Stick Duo slot; mini-B USB; 802.11b WLAN; stereo speakers; infrared listed; 480 × 272 display [H1] | Include the smallest physical-main-memory family in the budget and preserve a separate test record. An infrared dependency needs a deliberate hardware requirement. | NOT TESTED |
| PSP-2000 | UMD; Duo storage; mini-B USB; WLAN; stereo speakers; video output. Sony also describes caching UMD game data to reduce load time [H2] | Keep UMD/cache behavior separate from Memory Stick launch behavior. Video-output tests need their own conditions; launch evidence is not a TV-output result. | NOT TESTED |
| PSP-3000 | UMD; Duo storage; mini-B USB; WLAN; stereo speakers; video output; built-in microphone; improved LCD [H3] | A built-in-microphone feature needs a capability check or an explicit requirement. The same 480 × 272 output dimensions do not make all display behavior identical. | NOT TESTED |
| PSP Go / PSP-N1000 | No UMD playback; 16 GB internal flash storage; M2 slot; multi-use connector; Bluetooth 2.0 EDR; WLAN; stereo speakers; microphone; 3.8-inch 480 × 272 display [H4] | Test internal storage and M2 separately and do not assume every launch uses one universal volume prefix. Do not require a UMD. Check cable, remote, audio route and Bluetooth assumptions independently. The 16 GB flash is persistent storage, not RAM. | NOT TESTED |
| PSP Street / PSP-E1000 | UMD; Duo storage; mini-B USB; no Wi-Fi; built-in mono speaker; headset connector; 480 × 272 display [H5, H6] | WLAN-dependent features cannot be required on this family. A stereo-speaker claim cannot be verified with its built-in speaker; test the headset route separately. The cited sources do not establish every microphone or codec-module capability. | NOT TESTED |

All five Sony specification tables list a POWER/HOLD switch [H1–H5]. PSPSDK also declares `PSP_CTRL_HOLD = 0x020000` [H13]. Those facts do not verify that a particular user-mode input call exposes all physical switch transitions, that controls resume correctly, or that audio remains stable during HOLD. Keep physical switch, reported input bit, application policy and observed behavior as separate fields. This task supplies no HOLD diagnosis.

The Sony releases state supported consumer music formats; that is evidence about the product's advertised playback behavior, not a promise that an arbitrary homebrew user-mode import can directly call each decoder. In particular, no claim about an ATRAC, MP3 or AAC firmware module should be promoted to PASS merely because a format appears in a product brochure.

## Firmware architecture: an evidence-backed integration view

Treat the firmware as a set of services reached through a binary interface, rather than as a collection of desktop shared libraries copied into an EBOOT.

| Boundary | What the cited source establishes | What remains to be demonstrated |
| --- | --- | --- |
| Application module metadata | `pspmoduleinfo.h` defines the module-info structure, import/export table bounds and different USER/KERNEL attributes [H9]. | That the built image is accepted in its selected launch context. Setting an attribute does not establish an authorized privilege transition. |
| Imports | The SDK's assembly macros encode library information and 32-bit function identifiers in stub/NID sections [H10]. | That the target firmware exports the required library/NID combination in the application's context. A successful host link only proves the SDK supplied a matching stub. |
| Module lifecycle | `pspmodulemgr.h` documents load, start, stop and unload as different operations. It also documents restrictions on loading from some locations or loading plain executables through the MS API [H11]. | Each operation's return value and module-start status on the actual target. A PRX filename's presence is not a successful load or start. |
| Optional user-mode service modules | `psputility_modules.h` declares module identifiers and `sceUtilityLoadModule()`; `psputility_avmodules.h` declares the older AV loader and dependency comments [H12]. | Firmware availability, dependency state, permissions and initialization success for each selected module. The older AV and unified loader identifiers are different namespaces. |
| Memory and GE services | The user sysmem header documents allocation/free-memory queries; the GE header documents an enabled VRAM query [H7, H8]. | Actual available bytes, fragmentation and working graphics buffers for the build under test. Installed memory does not supply these numbers. |

For example, the older AV namespace assigns `PSP_AV_MODULE_ATRAC3PLUS = 2` and comments that AVCODEC must load first; the unified namespace assigns `PSP_MODULE_AV_ATRAC3PLUS = 0x0302`. Passing a constant from the wrong namespace is a caller error. These source declarations support explaining the interface, not certifying a stock-OFW decoder matrix. [H12]

The SDK sysmem header distinguishes `sceKernelDevkitVersion()` (firmware version query) from setting or retrieving the SDK version recorded for the caller. Do not treat a compile-time firmware macro or compiled-SDK setting as the installed firmware identity. Sony's manual identifies the on-device System Information screen and its System Software field as the place to read the displayed version [H6, H8]. Preserve both the displayed firmware string and any supported runtime API's raw value in a test record.

The listed APIs and metadata support an engineering account of the application/firmware boundary. The cited public sources do not fully specify Sony's internal boot chain, cryptographic acceptance policy, scheduler implementation, firmware memory map, or every model-specific service module. Those details remain UNKNOWN here unless another chapter supplies separately pinned primary evidence.

## Suggested evidence rows for later device testing

These are required records to collect, not results already obtained:

- Family and complete model suffix; displayed System Software; stock-OFW/CFW status and evidence.
- Exact EBOOT hash, source commit, SDK pin, compiler flags and import inventory.
- Launch medium and selected content root, including internal-flash versus M2 cases on Go.
- XMB recognition, process entry and each optional module's load/start/initialization results separately.
- Total free memory, largest free block and queried GE VRAM at named checkpoints, if the required APIs are supported.
- Speaker/headphone/Bluetooth route; channel test; HOLD transitions; suspend/resume observations; exact numeric error and stage for every failure.

Until a row contains observations from its stated hardware/firmware/build combination, its result remains **NOT TESTED**. Unknown capabilities remain **UNKNOWN**. Neither PPSSPP nor SDK declarations fill those rows.

## Source register

- **H1** — Sony Computer Entertainment, 2004-10-27. [PSP-1000 launch specifications](https://sonyinteractive.com/en/press-releases/2004/psp-enters-the-market-on-december-12-2004-at-19800-yen-in-japan/). Supporting phrases: "Main Memory | 32MB"; "Embedded DRAM | 4MB". Later models' eDRAM cannot be inferred from this release.
- **H2** — Sony Computer Entertainment, 2007-07-12. [PSP-2000 announcement and specifications](https://sonyinteractive.com/en/press-releases/2007/pspplaystationportable-becomes-slimmer-and-lighter/). Supporting phrases: "Main Memory | 64MB"; "Analog Video Out". Caching benefit is title-dependent in the release.
- **H3** — Sony Computer Entertainment Japan, 2008-09-02. [PSP-3000 announcement and specifications](https://sonyinteractive.com/en/press-releases/2008/sony-computer-entertainment-japan-to-introduce-new-psp-playstationportable-with-advanced-high-contrast-lcd-this-october-in-japan/). Supporting phrases: "Main Memory | 64MB"; "built-in microphone".
- **H4** — Sony Computer Entertainment, 2009-06-03. [PSP Go announcement and specifications](https://sonyinteractive.com/en/press-releases/2009/psp-go-psp-playstationportable-evolves-to-match-the-digital-lifestyle/). Supporting phrases: "Main memory 64MB"; "16GB (Flash Memory)"; "Content on UMD cannot be played back on PSPgo."
- **H5** — Sony Computer Entertainment Europe, published 2011-08-17; announcement text dated 2011-08-16. [PSP-E1000 announcement and specifications](https://sonyinteractive.com/en/press-releases/2011/sony-computer-entertainment-europe-announces-new-model-of-psp-playstationportable-at-an-attractive-price-point-of-9999-rrp/). Supporting phrases: "Main memory 64MB"; "will not offer access to Wi-Fi connectivity"; "Built-in monaural speaker". The launch release supplies the RAM figure; H6 does not.
- **H6** — Sony Computer Entertainment, [PSP-E1000 instruction manual, English](https://www.playstation.com/content/dam/global_pdc/en/corporate/support/manuals/psp-docs/ENEU_PSP%20E-1000_Web.pdf). Relevant sections: "Checking the system software version," "Specifications," "Compatible media." Supporting phrases: "System Software"; "Monaural speaker". Historical store and update-service instructions in this manual are not a current service-availability claim.
- **H7** — PSPDEV, [pinned GE header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/ge/pspge.h#L69). Supporting phrase: "The size of VRAM (in bytes)." No fixed return value is documented.
- **H8** — PSPDEV, [pinned user sysmem header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/user/pspsysmem.h#L45). Supporting phrases: "Get the total amount of free memory"; "Get the size of the largest free memory block." No per-family application-memory number is documented.
- **H9** — PSPDEV, [pinned module-info header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/user/pspmoduleinfo.h#L19). Supporting code: `PSP_MODULE_USER = 0`; `PSP_MODULE_KERNEL = 0x1000`.
- **H10** — PSPDEV, [pinned stub macros](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/base/pspstub.s#L3) and [pinned import macros](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/base/pspimport.s#L2). Supporting phrase: "32-bit SHA1-derived NID value." This describes the SDK stub interface, not a universal promise about every firmware identifier.
- **H11** — PSPDEV, [pinned module-manager header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/user/pspmodulemgr.h#L59). Supporting phrases: "Load a module"; "Start a loaded module"; "Unload a stopped module".
- **H12** — PSPDEV, [pinned unified utility-module header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/utility/psputility_modules.h#L35) and [pinned AV-module header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/utility/psputility_avmodules.h#L20). Supporting phrase: "Load an audio/video module (PRX) from user mode." The header labels the older loader as available from firmware 2.00; this guide has not independently executed that version boundary.
- **H13** — PSPDEV, [pinned controller header](https://github.com/pspdev/pspsdk/blob/6ef2b21dc440ef8d4125f000301faaa2a470975e/src/ctrl/pspctrl.h#L80). Supporting code: `PSP_CTRL_HOLD = 0x020000`. Declaration does not verify physical-switch behavior in a given application.

No universal directory-name length limit was inferred in this research.

