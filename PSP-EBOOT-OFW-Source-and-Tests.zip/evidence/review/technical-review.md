# Independent technical review

Review stage: source, laboratory tools and recorded technical evidence. Final PDF, companion ZIP, external manifests, rendered-page QA and full command replay were not yet available for final-artifact review. This is not final publication approval.

Reviewed original requirements, repository AGENTS.md, design/implementation plan, progress ledger, pspguide modules, CLI launchers, SampleApp, tests, chapter prose, source pins, build/negative/runtime reports and relevant pinned signer code. No production edits, rebuild, firmware writes or physical tests were performed. The only executed probes used temporary owned packaging fixtures or in-memory synthetic parser data.

## Important — Reserve a requested report before publishing an artifact

Location: tools/_cli.py:12–19, specifically line14; reached by tools/package_release.py and tools/safe_sign.py.

`run()` executes the operation before `emit()` exclusively creates the requested report. If the report already exists (or its parent is unavailable), signing/packaging can publish a new artifact and then return exit1 with status FAIL containing only the report filesystem error. A rerun then fails on the new artifact. This loses the successful artifact report and makes the command's failure status misrepresent which operation completed. Existing files remain preserved; this finding is about publication/report consistency, not an overwrite of existing data.

Observed isolated CLI probe: create a staging directory containing README.md, LICENSE.txt and VALIDATION.md; create existing.json containing `preserve`; invoke `python3 -B tools/package_release.py STAGE NEW.zip --report existing.json`. Result: exit1, stdout status FAIL/File exists, NEW.zip exists, existing.json unchanged. The fixture was removed automatically after the observation.

Recommendation: exclusively reserve/validate the report destination before invoking a side-effecting operation, retain no-overwrite semantics, and clearly handle report-writing failure after artifact creation. Regression: existing report, report/output alias and nonexistent report parent must prevent the work callback and artifact publication; normal success and failed operations must still produce accurate reports.

## Important — Reject relocation storage that aliases mutable ELF metadata before legacy invocation

Location: pspguide/formats.py:190–199; pspguide/sign.py:40–51. Relevant pinned legacy source: ../upstream/ebootsigner/fix-realocations.c:40–48.

The parser bounds relocation bytes and their decoded target fields but does not require relocation record storage to be disjoint from ELF headers or structural tables. The C relocation pass writes through that storage while rereading `elf_hdr->e_shoff` and section headers in its loop. Thus initial bounds validation does not guarantee the C loop continues using the table that Python checked. Post-sign verification is too late to protect those earlier C reads.

The in-memory probe below passes `validate_unsigned()` and `require_user_profile()` with the real pinned SDK map. Its relocation record is physically at byte28: r_offset is e_phoff=52 and r_info is e_shoff=0x10007. Both referenced LOAD indices pass. Clearing type7 changes e_shoff to0x10000; the predicted transformed PRX then fails parsing with `ELF section-name string table`. No native signer was invoked, and no malformed file was saved. This proves accepted self-modifying structural metadata; it is not a claim that this particular fixture was observed to crash C.

```python
from tests.fixtures import prx, pbp
from pspguide.formats import validate_unsigned, adjust_relocations, parse_prx
from pspguide.nids import inventory, load_map, require_user_profile
import struct
b = bytearray(prx())
old = struct.unpack_from('<I', b, 32)[0]
table = bytes(b[old:old + 400])
new = 0x10007
b.extend(b'\0' * (new + 400 - len(b)))
b[new:new + 400] = table
struct.pack_into('<I', b, 32, new)
struct.pack_into('<H', b, 44, 2)
struct.pack_into('<8I', b, 84, 1, 0x100, 0x10000, 0,
                 0xc0, 0xe0, 7, 0x100)
struct.pack_into('<I', b, new + 9 * 40 + 16, 28)
_, parsed, _ = validate_unsigned(pbp(payload=bytes(b)))
audit = inventory(parsed, load_map('references/user-nids.json'))
require_user_profile(audit)  # currently accepts
transformed, count = adjust_relocations(parsed)
assert struct.unpack_from('<I', transformed, 32)[0] == 0x10000
parse_prx(transformed)  # currently raises FormatError
```

Recommendation: reject relocation storage overlap with ELF/program/section tables, structural non-relocation sections and other relocation storage before C execution; also prevalidate the predicted allowed transformation and metadata continuity. Add focused regression fixtures for each alias class and assert signer invocation is absent. Preserve the valid real SampleApp path without rebuilding it.

## Verified review observations

- Recomputed every file recorded in references/source-file-pins.json against the cached pinned sources: no mismatches.
- Regenerated the NID map from those cached SDK sources: exact equality with references/user-nids.json.
- Recomputed the hashes of both existing builds' ELF, PRX, unsigned PBP and signed PBP: all match evidence/reproducibility.json. Signed PBP is d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47.
- The correct Kernel_Library mutex/interrupt labels are present. VERIFIED is explicitly SDK mapping only, and the map's self-declared revision is explicitly not treated as independent authentication.
- The real negative-control summary distinguishes10 expected rejections and2 accepted padding-boundary controls plus1 oversized rejection (13 actual CLI executions); the boundary fixtures are explicitly not signing/runtime results.
- The recorded corrected host suite has32 passing tests; its earlier noexec fixture error remains preserved. No broad suite was rerun during review.
- Runtime attempt005 records six direct-path cold launches with live readiness/heartbeat, CROSS exit_reason2, arrival at ExitGame import and game.quit. Folder observations and memory values are scoped to PPSSPP. Physical OFW and physical HOME callback remain NOT TESTED; no performance claim is inferred.
- The parser/profile is intentionally narrow, not a generic hostile-file VM. No request is made here for unsupported import forms, arbitrary applications or general firmware-loader emulation.

## Limitations and pending completion checks

No Critical findings established in this stage. The two Important findings require fixes and targeted regression evidence before source review can close. Final delivery still requires review of generated PDF/attachment, all four final files, exact source/example consistency, complete commands, links, licenses, and the producer's every-page visual inspection. Narrative expansion markers are expected in the current source and must not survive into the final PDF. Runtime observations are reviewed as recorded evidence, not independently rerun hardware tests. No production files or original inputs were modified by this reviewer.


## Follow-up: both Important findings closed at source level

Reviewed the updated tools/_cli.py, pspguide/formats.py and six tests in tests/test_review_regressions.py. The CLI now reserves a requested report before invoking the operation and rejects report/output aliases. The relocation parser now requires record storage to be disjoint from the ELF header, program/section tables, all LOAD file bytes, non-relocation file sections and other relocation sections. That directly blocks the demonstrated mutable-table path. Given these disjointness guarantees, a separate predicted-transform parse before C invocation is not required to close this particular finding.

Retained RED evidence is evidence/review-regressions-red.log. The producer's focused evidence/cli-regression-final.log records6/6 PASS, and evidence/host-final.log records38/38 PASS. Reviewed the two after-review preflight/independent-verification reports: both PASS on the original unchanged SampleApp artifact hashes. The earlier32-test evidence remains preserved. No broad tests or builds were rerun by this reviewer.

Reviewed REPRODUCE.md and document/lab-commands.md. SDK build, signer, preflight, NID, independent verifier, comparison and negative-control commands match the supplied CLI interfaces and use fresh destinations. The source acquisition boundary correctly puts network access before the offline job; immutable base identity versus mutable package availability and UNKNOWN installed SDK source commit remain explicit. Appended commands do not authorize writing a physical PSP or firmware.

Minor documentation recommendation: the runtime section currently lists dependencies, `--help` and option names without one complete executable invocation. Add a concrete runtime_sample.py command using the supplied artifacts and an explicit AppImage extraction/location/container setup reference. This makes the recorded experiment easier to replay without inferring paths or environment setup.

Source-level Important findings:0 open. Final PDF/real companion approval remains pending; a draft containing the temporary installer attachment is not the final publication.


## Source/document review closure before companion freeze

Reviewed evidence/runtime/REPLAY.md and the added REPRODUCE.md staging instructions. The runtime recipe now provides exact acquisition/hash checks, extraction, owned cache/container paths, dependency setup and all harness arguments for the six cases. It explicitly distinguishes the reconstructed recipe from the actual preserved run, and does not claim the normalized recipe was re-executed. The Minor runtime-instructions recommendation is closed.

No Critical, Important or Minor source-review findings remain open. This closure covers the reviewed tools, narrative source and instructions; it does not replace the pending independent check of the final PDF, real embedded companion, external checksums and completed delivery files. The producer reports visual inspection of all36 typeset pages; this reviewer has not independently claimed to have visually inspected every page at this point.
