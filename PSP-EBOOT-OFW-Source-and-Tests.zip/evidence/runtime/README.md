# SampleApp runtime evidence

`attempt-005/report.json` records six successful, sequential cold launches in
PPSSPP v1.20.4 on 2026-10-29 UTC. The signed EBOOT SHA256 is
`d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47`.

| ASCII folder bytes | Ready | Heartbeat | CROSS → reason 2 → exit import → game.quit |
| ---: | :---: | :---: | :---: |
| 1 | PASS | 5 → 10 | PASS |
| 9 (`SampleApp`) | PASS | 4 → 10 | PASS |
| 31 | PASS | 5 → 10 | PASS |
| 32 | PASS | 2 → 8 | PASS |
| 33 | PASS | 2 → 8 | PASS |
| 64 | PASS | 4 → 10 | PASS |

Each case used its own XDG configuration and memory-stick directory. The harness
sent CROSS through `input.buttons.send`; the unchanged application consumed it
through `sceCtrlPeekBufferPositive`. It read globals at addresses from the
matching linked ELF and stopped the interpreter at the exit import derived from
the raw PRX's `LoadExecForUser` NID `0x05572A5F`. PC was `0x08820b28` and
`sample_exit_reason` was 2. Resuming executed the exit path; every case then
emitted `game.quit` and reported PC 0 with the CPU paused. The harness did not
write application memory or registers.

All six cases reported free-total 22,865,408 bytes, free-max 22,603,264 bytes and
GE EDRAM 2,097,152 bytes under the emulator's `PSPModel=0` configuration. These
are emulator measurements. No performance or long-run stability claim follows.

The independent runtime-validation agent directly inspected
`attempt-005/folder-009/ready-screen.png` with the image-viewing tool. Its four
visible lines are `SampleApp - User Mode`, `Physical stock OFW: NOT TESTED`,
`CROSS: application exit`, and `HOME: exit callback`. The screenshot SHA256 is
`f33f08f43ed7cb80cc3303559244747666827a7755084e8a52914025d7e87167`.
The generated report's screenshot review field remains `PENDING`; this README
and `index.json` record the subsequent direct visual review without rewriting
that original report.

The four earlier reports retain their original **FAIL** status:

| Attempt | Harness failure and technical reason for retake |
| --- | --- |
| 001 | The package booted, but the harness could not connect to assumed port 8080. |
| 002 | Precreating the startup INI did not resolve the assumed-port failure. A socket-table observation exposed an ephemeral listener; PPSSPP's default `RemoteISOPort` is 0. |
| 003 | The WebSocket connected, but the harness requested module metadata before CPU startup completed and aborted on `CPU not active`. |
| 004 | Readiness, heartbeat, CROSS, exit reason, the exit import and `game.quit` were observed. The harness nevertheless timed out awaiting a ticketed `cpu.resume` reply; that API completes through an asynchronous event. |

Attempt 005 explicitly selected the port and debugger protocol, waited for CPU
startup, and handled the asynchronous resume event. These were harness retakes;
none of the retained failures establishes a SampleApp logic failure. Raw logs
also retain PPSSPP's ISO-probe error messages before successful PBP boot and
after exit; the logs are not presented as error-free.

This test directly launched owned `PSP/GAME/<name>/EBOOT.PBP` paths. It does not
test physical PSP XMB discovery, stock OFW signature/import acceptance, or a
Sony folder-name limit. Lengths 33 and 64 deliberately bypass the publisher's
1–32 ASCII-byte release policy for diagnosis. **Physical stock OFW and the
physical HOME exit callback remain NOT TESTED.**

The cached AppImage SHA256 is
`661c098e6b7f7610171a57b7c533ce8bba6f2312b71e76d61e850461973eba21`.
The exact launcher and shared-payload hashes are in the report. The owned
container and image are named `psp-guide-runtime-20261029`; its image ID is
`sha256:a179ffeb7e28cd0324d95b298c389281d4d32de72b97f78ba8c55ca1a868904e`.
It used the pinned Python base recorded in `environment.json`, Xvfb, Mesa,
interpreter `-i`, and a read-only `/emulator` cache bind. `environment.json`
retains dependency versions and installation output. No emulator process was
left running after the matrix.

`index.json` contains the report index, visual-review record and SHA256 manifest
of retained evidence. The reproducible harness is `tools/runtime_sample.py` at
the source root. Its output directory must be new; earlier attempts are never
overwritten. HiFiPlayer, original distributions and firmware archives were not
modified or used by this validation.
