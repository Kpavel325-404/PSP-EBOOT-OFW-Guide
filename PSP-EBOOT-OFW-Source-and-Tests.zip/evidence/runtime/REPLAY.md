# Replay the PPSSPP runtime matrix

Use Linux x86_64, or Windows 11 with WSL2 and Docker Desktop, with Docker,
`curl`, `sha256sum` and network access. Start in the extracted companion's
`source` directory. Its preserved inputs are `artifacts/build-a/EBOOT-signed.PBP`,
`SampleApp.elf` and `SampleApp.prx`; the source is `sample/main.c`. This replay
does not rebuild or resign those artifacts.

The commands below are a **reconstructed replay recipe**, based on the actual
runtime setup and [environment.json](environment.json). This exact normalized
recipe was not executed. The recorded run is [attempt-005/report.json](attempt-005/report.json),
which used the same AppImage, base image and dependency versions. The AppImage,
base image and Python dependencies below are pinned. Debian's repositories can
change; `environment.json` preserves every installed Debian package version and
the actual installation log. These commands do not promise a byte-identical
derived container image when different Debian package versions are available.

The [official PPSSPP download page](https://www.ppsspp.org/download/) links Linux
AppImages to the project's GitHub releases. The
[v1.20.4 asset list](https://github.com/hrydgard/ppsspp/releases/expanded_assets/v1.20.4)
publishes the exact x86_64 asset and SHA256 used here. Acquire it in a **new**
owned cache; do not overwrite an existing emulator cache:

```sh
set -eu
PSP_LAB_ROOT="$(cd .. && pwd)"
PSP_RUNTIME_CACHE="${PSP_LAB_ROOT}-ppsspp-runtime-replay"
mkdir "$PSP_RUNTIME_CACHE"
curl --fail --location \
  --output "$PSP_RUNTIME_CACHE/PPSSPP-v1.20.4-anylinux-x86_64.AppImage" \
  'https://github.com/hrydgard/ppsspp/releases/download/v1.20.4/PPSSPP-v1.20.4-anylinux-x86_64.AppImage'
(
  cd "$PSP_RUNTIME_CACHE"
  sha256sum --check <<'APPIMAGE_SHA256'
661c098e6b7f7610171a57b7c533ce8bba6f2312b71e76d61e850461973eba21  PPSSPP-v1.20.4-anylinux-x86_64.AppImage
APPIMAGE_SHA256
)
```

Continue only if that check succeeds. Extract without FUSE, normalize the
extracted directory to `AppDir`, and check both measured executable layers:

```sh
(
  set -eu
  cd "$PSP_RUNTIME_CACHE"
  chmod u+x PPSSPP-v1.20.4-anylinux-x86_64.AppImage
  ./PPSSPP-v1.20.4-anylinux-x86_64.AppImage --appimage-extract
  if [ ! -d AppDir ] && [ -d squashfs-root ]; then
    mv squashfs-root AppDir
  fi
  test -x AppDir/bin/PPSSPPSDL
  sha256sum --check <<'EXTRACTED_SHA256'
18d970f56eca2c527ffd3993b161b6bc340055129db14b394a77cb67d8bbfff9  AppDir/bin/PPSSPPSDL
69756222b9a94b82de0bbfc8e3bf711dc231f9f6929e2ab2cd961be3f408e94f  AppDir/shared/bin/PPSSPPSDL
EXTRACTED_SHA256
)
```

The harness must launch `AppDir/bin/PPSSPPSDL`, the measured SDL launcher, with
its complete extracted tree available. The `shared/bin` executable hash is an
additional identity check; it is not the harness's launch target.

Create a fresh owned container. The whole laboratory root is writable at `/lab`;
the sibling emulator cache is read-only at `/emulator` and has no writable alias
inside `/lab`. No firmware, card or unrelated
project mount is needed. These commands use Linux `docker`:

```sh
PSP_LAB_BIND="$PSP_LAB_ROOT"
PSP_EMULATOR_BIND="$PSP_RUNTIME_CACHE"
docker run -d --name psp-guide-runtime-replay --platform linux/amd64 \
  --mount "type=bind,source=$PSP_LAB_BIND,target=/lab" \
  --mount "type=bind,source=$PSP_EMULATOR_BIND,target=/emulator,readonly" \
  python@sha256:cd89c30eda26ee911a4611b18680086e0ea42e6f5f8cbe653d07fa7958c9cec8 \
  sleep infinity
```

For a Windows Docker CLI invoked as `docker.exe` from WSL2, set
`PSP_LAB_BIND="$(wslpath -w "$PSP_LAB_ROOT")"` and
`PSP_EMULATOR_BIND="$(wslpath -w "$PSP_RUNTIME_CACHE")"` before the run command,
and use `docker.exe` consistently in place of `docker`. Do not delete or reuse
an unrelated container if the chosen name already exists; select another owned
name and substitute it consistently.

Install the same directly requested Debian packages as the measured setup,
then the recorded Python versions. Debian's transitive dependencies and their
measured versions are listed in `environment.json`:

```sh
docker exec -i psp-guide-runtime-replay bash <<'RUNTIME_SETUP'
set -eu
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  xvfb libgl1 libegl1 libgles2 libvulkan1 libx11-6 libxcb1 libxrandr2 \
  libxi6 libxcursor1 libpulse0 libasound2t64 libsdl2-2.0-0 \
  libfontconfig1 libfreetype6 x11-utils x11-apps procps ca-certificates
python -m pip install 'websockets==17.3' 'pyelftools==0.33' 'Pillow==13.0.0'
RUNTIME_SETUP
```

Run this complete command once, with `/lab/runtime-replay` **absent** beforehand:

```sh
docker exec psp-guide-runtime-replay \
  python -B /lab/source/tools/runtime_sample.py \
  --eboot /lab/source/artifacts/build-a/EBOOT-signed.PBP \
  --elf /lab/source/artifacts/build-a/SampleApp.elf \
  --prx /lab/source/artifacts/build-a/SampleApp.prx \
  --source /lab/source/sample/main.c \
  --emulator /emulator/AppDir/bin/PPSSPPSDL \
  --appimage /emulator/PPSSPP-v1.20.4-anylinux-x86_64.AppImage \
  --expected-sha256 d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47 \
  --output /lab/runtime-replay \
  --lengths 1 9 31 32 33 64
```

The harness starts and cleans up its own Xvfb and sequential PPSSPP processes.
It selects interpreter `-i`, software Mesa, dummy audio, a separate XDG/memstick
per case, explicit debugger port 8080, the debugger WebSocket subprotocol, and
the correct startup/resume waits. Do not run another emulator in this container
concurrently. The advisory lock is `/lab/.runtime.lock` for this output path;
the six cases within the invocation are serialized.

Inspect `/lab/runtime-replay/report.json`, each `folder-*/result.json`, raw
`debugger.jsonl` and `ppsspp.log`, and
`folder-009/ready-screen.png`. A successful run exits 0 and reports all six
cases PASS; otherwise retain the FAIL output and its diagnostic logs. Inspect
the new screenshot directly before recording its visual review. Prior evidence
under `source/evidence/runtime` remains unchanged. Stop the owned idle container
when finished with `docker stop psp-guide-runtime-replay`.

This remains direct-path emulator validation. Physical stock OFW, physical HOME
callback and physical XMB discovery are NOT TESTED. The publisher's 32-byte
ASCII folder policy is separate from the deliberately tested 33/64-byte paths.
