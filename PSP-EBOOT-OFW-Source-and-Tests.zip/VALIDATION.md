# Validation of this installation artifact

EBOOT SHA256 d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47;
5,584,308 bytes. This is the same signed artifact from both independent builds.
Raw PRX159,058bytes; moduleSampleApp attr0; main USER0x80000000; linked stack32KiB
and heap2048KiB; SFO MEMSIZE0, PSP_SYSTEM_VER6.60.12 libraries/54 functions map to
the pinned public SDK user stubs: VERIFIED means SDK mapping only.

Host final suite38/38PASS;13 real-artifact negative CLI controlsPASS; two builds'
ELF/PRX/unsignedPBP/signedPBP byte-identical; separate PyCA CMAC/AES verifierPASS.
All six PPSSPP cold direct launches show ready/heartbeat/CROSS reason2/ExitGame/
game.quitPASS. Directory lengths1,9,31,32,33,64 are emulator observations only;
publisher installation policy remains1..32ASCII bytes.

Initial host noexec fixture ERROR and four runtime harness FAIL attempts are
retained and explained in the source companion. No malformed/boundary fixture
was sent to the signer or a device. Updated validators rechecked this existing
artifact after review; SampleApp was not rebuilt to change documented results.

All physical families, stock OFW6.60/6.61, physical XMB/HOME/suspend-resume:
NOT TESTED. Physical peak memory and performance: NOT MEASURED.

## Evidence locations

- `evidence/host-final.log`:38 final test methods; multiple malformed-input
  subcases are not inflated into a larger test count.
- `evidence/negative/summary.json`:13 actual CLI executions, expected rejection
  statuses distinguished from test PASS. Mutation generator is included.
- `evidence/reproducibility.json`, `environment/build-manifest.json`: actual
  two-build hashes plus independently read linked parameters.
- `evidence/sample-independent-after-review.json`: same signed bytes accepted
  by the updated validator after the two Important review findings were fixed.
- `evidence/runtime/README.md`, `index.json`, `attempt-005/report.json`: exact
  six emulator cases, screenshot review and retained attempts001-004FAIL.
- `evidence/links.json`:88 external URLs checkedHTTP200, fingerprints/anchors.
- `evidence/review/technical-review.md`: independent source review and closure.

## Open physical compatibility matrix

| Family | XMB/stock OFW6.60/6.61 launch | Physical HOME | Suspend/resume |
| --- | --- | --- | --- |
| PSP1000 | NOT TESTED | NOT TESTED | NOT TESTED |
| PSP2000 | NOT TESTED | NOT TESTED | NOT TESTED |
| PSP3000 | NOT TESTED | NOT TESTED | NOT TESTED |
| PSPGo/N1000 | NOT TESTED | NOT TESTED | NOT TESTED |
| PSPStreet/E1000 | NOT TESTED | NOT TESTED | NOT TESTED |

The small example is not an audio or peripheral workload. No broad application
stability, target firmware acceptance or long-run leak claim follows.
