#!/usr/bin/env python3
"""Execute damaged-copy CLI controls; keep failure reports and compact mutations.

Only new temporary copies are changed. Original artifacts are hashed before and
after. Large corrupted ciphertext copies are reconstructible, not duplicated in
the public companion. Synthetic/boundary inputs are never sent to the signer.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
import hashlib
import json
import struct
import subprocess
import tempfile
from pspguide.formats import parse_pbp,parse_prx,parse_sfo,need
from pspguide.verify import digest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--unsigned',type=Path,required=True)
    parser.add_argument('--signed',type=Path,required=True)
    parser.add_argument('--sources',type=Path,required=True)
    parser.add_argument('--nid-map',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    source=Path(__file__).resolve().parents[1]
    original=a.unsigned.read_bytes();signed=a.signed.read_bytes()
    u=parse_pbp(original);s=parse_pbp(signed);prx=parse_prx(u.sections[6])
    hashes=(digest(original),digest(signed));rows=[]
    module=next(x for x in prx.sections if x['name']=='.rodata.sceModuleInfo')
    text=next(x for x in prx.sections if x['name']=='.text')

    def changed(data,offset,value):
        b=bytearray(data);b[offset:offset+len(value)]=value;return bytes(b)

    def modify_sfo(data,key,value):
        c=parse_pbp(data);start=c.offsets[0];sfo=c.sections[0]
        _,_,ka,da,count=struct.unpack_from('<5I',sfo)
        for i in range(count):
            k,fmt,length,maximum,relative=struct.unpack_from('<HHIII',sfo,20+i*16)
            name=sfo[ka+k:sfo.index(b'\0',ka+k)].decode()
            if name==key:
                raw=struct.pack('<I',value) if isinstance(value,int) else value.encode()+b'\0'
                need(len(raw)==length,'Mutation preserves original SFO value width')
                return changed(data,start+da+relative,raw)
        raise ValueError('Mutation SFO key missing')

    def execute(label,unsigned_copy,signed_copy=None,command='cross_validate',expected='FAIL',explanation=''):
        report=a.output/(label+'.json')
        with tempfile.TemporaryDirectory(prefix='psp-negative-') as folder:
            work=Path(folder);up=work/'unsigned.pbp';sp=work/'signed.pbp'
            up.write_bytes(unsigned_copy)
            if signed_copy is not None:sp.write_bytes(signed_copy)
            cmd=[sys.executable,'-B',str(source/'tools'/f'{command}.py'),str(up)]
            if command=='cross_validate':cmd += [str(sp),'--sources',str(a.sources)]
            cmd += ['--nid-map',str(a.nid_map),'--report',str(report)]
            result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=30)
            need(report.is_file(),'CLI did not save a failure report: '+label)
            detail=json.loads(report.read_text());status=detail['status']
            success=status==expected and (result.returncode!=0 if expected=='FAIL' else result.returncode==0)
            rows.append(dict(case=label,expected_status=expected,observed_status=status,
                             exit_code=result.returncode,test_result='PASS' if success else 'FAIL',
                             error=detail.get('error'),reason=explanation,
                             unsigned_copy_sha256=digest(unsigned_copy),
                             signed_copy_sha256=digest(signed_copy) if signed_copy is not None else None,
                             report=report.name))
            need(success,'Negative/control unexpected result: '+label)

    execute('ciphertext-bit-flip',original,changed(signed,s.offsets[6]+0x150+32,
            bytes([signed[s.offsets[6]+0x150+32]^1])),explanation='Both CMACs and payload integrity are checked.')
    execute('wrapper-bit-flip',original,changed(signed,s.offsets[6]+5,
            bytes([signed[s.offsets[6]+5]^1])),explanation='Pinned outer wrapper must match exactly.')
    execute('sfo-resource-changed',original,modify_sfo(signed,'TITLE','TampleApp'),
            explanation='Non-DATA.PSP sections must match preserved unsigned input.')
    execute('truncated-signed-pbp',original,signed[:-1],explanation='Original final section offset is now outside file.')
    alternate=changed(original,u.offsets[6]+text['offset']+16,
                      bytes([original[u.offsets[6]+text['offset']+16]^1]))
    execute('different-original-prx',alternate,signed,explanation='Entire expected PRX prefix, not just ELF magic, must match.')
    for key,value in [('MEMSIZE',1),('PSP_SYSTEM_VER','9.99')]:
        execute('matching-bad-'+key.lower(),modify_sfo(original,key,value),modify_sfo(signed,key,value),
                explanation='Crypto payload unchanged and both SFO copies match; explicit SampleApp profile must still reject.')
    bad=changed(original,u.offsets[6]+32,struct.pack('<I',0xfffffff0))
    execute('elf-section-table-outside-file',bad,command='preflight_pbp',explanation='Reject ELF range before legacy execution.')
    bad=changed(original,u.offsets[6]+module['offset'],struct.pack('<H',0x1000))
    execute('kernel-inner-module',bad,command='preflight_pbp',explanation='Declared kernel attribute conflicts with the selected user profile.')
    nid_at=prx.address(prx.imports[0]['nid_address'],4)
    bad=changed(original,u.offsets[6]+nid_at,struct.pack('<I',0xdeadbeef))
    execute('unknown-import-nid',bad,command='preflight_pbp',explanation='Unknown NID is UNKNOWN, then refused by the conservative signing policy.')

    # Retain the complete real PRX and add unused trailing bytes. No padded
    # boundary fixture is passed to the C signer, emulator or physical device.
    base_header=bytearray(original[:u.offsets[6]])
    for length,expected in [(0x3fffff,'PASS'),(0x400000,'PASS'),(0x400001,'FAIL')]:
        h=bytearray(base_header);struct.pack_into('<I',h,36,u.offsets[6]+length)
        payload=u.sections[6]+b'\0'*(length-len(u.sections[6]))
        execute('raw-size-'+str(length),bytes(h)+payload,command='preflight_pbp',expected=expected,
                explanation='Complete compiled PRX plus padding; preflight size policy only, never a signer or runtime result.')
    need((digest(a.unsigned.read_bytes()),digest(a.signed.read_bytes()))==hashes,'Original artifacts changed')
    summary=dict(status='PASS',rows=rows,original_unsigned_sha256=hashes[0],
                 original_signed_sha256=hashes[1],originals_unchanged=True,
                 actual_CLI_executions=len(rows),damaged_copies_removed_after_reports=True,
                 reconstruction='Run this generator against the included exact base artifacts; mutations and error classes are deterministic.',
                 physical_OFW='NOT TESTED')
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
    return 0


if __name__=='__main__':raise SystemExit(main())
