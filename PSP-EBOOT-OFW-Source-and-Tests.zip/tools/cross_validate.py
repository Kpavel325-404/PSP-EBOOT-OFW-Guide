#!/usr/bin/env python3
"""Independent crypto/profile verification plus pinned SDK import inventory."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
from pspguide.sign import read_limited
from pspguide.verify import verify
from pspguide.formats import validate_unsigned
from pspguide.nids import inventory,load_map,require_user_profile
from _cli import run

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("unsigned",type=Path);p.add_argument("signed",type=Path)
    p.add_argument("--sources",type=Path,required=True);p.add_argument("--nid-map",type=Path,required=True)
    p.add_argument("--report",type=Path);a=p.parse_args()
    def work():
        unsigned=read_limited(a.unsigned);result=verify(unsigned,read_limited(a.signed),a.sources)
        _,prx,_=validate_unsigned(unsigned);audit=inventory(prx,load_map(a.nid_map));require_user_profile(audit)
        result.update(import_audit=audit,import_mapping="VERIFIED (SDK mapping only)")
        return result
    return run(work,a)
if __name__=="__main__":raise SystemExit(main())
