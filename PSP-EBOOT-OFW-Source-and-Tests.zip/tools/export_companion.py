#!/usr/bin/env python3
"""Copy an explicit public release allowlist to a NEW staging tree, then ZIP.

No Git internals, user attachments, upstream binaries/sources or unrelated
workspace paths are eligible. Existing staging/output paths are refused.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
import hashlib
import json
import shutil
from pspguide.release import fresh_zip

DIRECTORIES=('pspguide','tools','tests','sample','artifacts','packages','references',
             'environment','research','document','evidence','licenses')
FILES=('README.md','LICENSE.txt','VALIDATION.md','THIRD_PARTY_NOTICES.md',
       'REPRODUCE.md','Dockerfile','requirements-lab.txt','requirements-document.txt')


def export(stage,output):
    source=Path(__file__).resolve().parents[1]
    if stage.exists():raise ValueError('Fresh public staging directory required')
    if output.exists():raise ValueError('Fresh companion destination required')
    selected=[source/name for name in FILES]
    for directory in DIRECTORIES:
        selected += [p for p in (source/directory).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    stage.mkdir(parents=True,exist_ok=False)
    for path in sorted(selected):
        if path.is_symlink():raise ValueError('Public source symlink refused')
        target=stage/path.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
        if hashlib.sha256(path.read_bytes()).digest()!=hashlib.sha256(target.read_bytes()).digest():
            raise ValueError('Staging copy changed')
    return fresh_zip(stage,output)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
    a=p.parse_args()
    # Reserve report before copying/publication, matching the shared CLI contract.
    with a.report.open('x',encoding='utf-8') as report:
        result=export(a.stage,a.output);report.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','members','archive_sha256']}))
