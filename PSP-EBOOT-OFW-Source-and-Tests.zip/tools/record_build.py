#!/usr/bin/env python3
"""Record existing measured build/environment bytes without recompiling anything."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def record(root,image_id):
    sdk=Path(subprocess.check_output(['psp-config','--pspsdk-path'],text=True).strip())
    commands={'psp-gcc':['--version'],'psp-ld':['--version'],'make':['--version'],
              'cc':['--version'],'python':['--version']}
    names=[*commands,'psp-prxgen','psp-fixup-imports','mksfoex','pack-pbp','unpack-pbp']
    tools={}
    for name in names:
        path=Path(shutil.which(name));item={'path':str(path),'sha256':digest(path)}
        if name in commands:item['version']=subprocess.check_output([name,*commands[name]],text=True).splitlines()[0]
        tools[name]=item
    files={}
    for build in ['build-a','build-b']:
        folder=root/build
        files[build]={str(p.relative_to(folder)):{'bytes':p.stat().st_size,'sha256':digest(p)}
            for p in sorted(folder.rglob('*')) if p.is_file()}
    compare=['main.c','Makefile','PARAM.SFO','SampleApp.elf','SampleApp.prx','EBOOT.PBP','EBOOT-signed.PBP']
    equality={name:files['build-a'][name]['sha256']==files['build-b'][name]['sha256'] for name in compare}
    if not all(equality.values()):raise ValueError('Existing measured build mismatch')
    project=root/'source'
    source_equal={name:digest(project/'sample'/name)==files['build-a'][name]['sha256'] for name in ['main.c','Makefile']}
    if not all(source_equal.values()):raise ValueError('Published source differs from compiled snapshot')
    reference=root/'upstream/pspsdk/src/base/build.mak'
    installed=sdk/'lib/build.mak'
    return {'status':'PASS','scope':'Read-only provenance capture of existing builds; no compile/sign rerun',
      'base_image':'pspdev/pspdev@sha256:54895e6f5afb71b8f4f6915ee6d5023e1e087ca7afdf2dcb1d7a694a5233e45f',
      'final_derived_image_id':image_id,'installed_sdk_source_revision':'UNKNOWN',
      'reference_sdk_revision':'e2b2b313d4175823a263c2c6cf175311e824eb77',
      'installed_build_rule_sha256':digest(installed),
      'reference_build_rule_sha256':digest(reference),
      'installed_rule_matches_reference_bytes':digest(installed)==digest(reference),
      'sdk_libraries':{str(p.relative_to(sdk)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted((sdk/'lib').glob('*')) if p.is_file()},
      'tools':tools,'python':sys.version,'platform':platform.platform(),
      'python_dependencies':{name:importlib.metadata.version(name) for name in ['cryptography','cffi','pycparser','pyelftools']},
      'lock_files':{name:digest(project/name) for name in ['Dockerfile','environment/apk-lock.txt','requirements-lab.txt']},
      'builds':files,'two_build_equality':equality,'source_matches_compiled_snapshot':source_equal,
      'legacy_signer_sha256':digest(root/'upstream/ebootsigner/ebootsign'),
      'cflags':'-O2 -G0 -Wall -Wextra -Werror -ffunction-sections -fdata-sections',
      'ldflags':'-Wl,--gc-sections,-Map,build/SampleApp.map',
      'source_identity':'Exact main.c/Makefile hashes above; fresh builds existed before current guide source commits',
      'physical_stock_ofw':'NOT TESTED'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True)
    p.add_argument('--image-id',required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    result=record(a.root,a.image_id)
    with a.report.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'source_matches':result['source_matches_compiled_snapshot'],
        'two_build_equality':result['two_build_equality'],'installed_rule_matches_reference':result['installed_rule_matches_reference_bytes']}))
