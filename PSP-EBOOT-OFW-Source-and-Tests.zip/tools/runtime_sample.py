#!/usr/bin/env python3
"""Run genuine SampleApp integration cases in an isolated PPSSPP Linux runtime.

Run inside the owned runtime container with /lab and read-only /emulator mounts.
Requires Xvfb, Mesa, Pillow, pyelftools and websockets. This is an observation
harness: it never writes PSP memory/registers and makes no OFW acceptance claim.
Each output directory is created exclusively, preserving failed attempts.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import datetime
import fcntl
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import struct
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True

from elftools.elf.elffile import ELFFile
from PIL import ImageGrab
import websockets

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pspguide.formats import parse_prx

EXPECTED_EBOOT = "d82c452f1b8200fab75d3bd54878da5dea7b364fc8119e80cb868bee5fcf6f47"
GLOBALS = ("sample_ready", "sample_heartbeat", "sample_exit_reason",
           "sample_free_total", "sample_free_max", "sample_ge_bytes")
SCOPE = ("PPSSPP emulator observation only; launching a package by its owned "
         "PSP/GAME path is not a physical PSP XMB installation test, a Sony "
         "folder-name limit, or stock OFW signature/import acceptance.")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


class Debugger:
    def __init__(self, ws, journal):
        self.ws, self.journal = ws, journal
        self.ticket = 0
        self.events = []

    def log(self, direction, message):
        self.journal.write(json.dumps({"utc": utc(), "direction": direction,
                                       "message": message}) + "\n")
        self.journal.flush()

    async def receive(self, timeout):
        value = json.loads(await asyncio.wait_for(self.ws.recv(), timeout))
        self.log("receive", value)
        self.events.append(value)
        return value

    async def request(self, event, notification=False, **params):
        self.ticket += 1
        ticket = str(self.ticket)
        request = {"event": event, "ticket": ticket, **params}
        self.log("send", request)
        await self.ws.send(json.dumps(request))
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            response = await self.receive(max(0.01, deadline - time.monotonic()))
            if response.get("ticket") == ticket or (notification and response.get("event") == event):
                if response.get("event") == "error":
                    raise RuntimeError(f"{event}: {response}")
                return response
        raise TimeoutError(event)

    async def snapshot(self, base, symbols):
        lower, upper = min(symbols.values()), max(symbols.values()) + 4
        reply = await self.request("memory.read", address=base + lower,
                                   size=upper - lower)
        data = base64.b64decode(reply["base64"], validate=True)
        if len(data) != upper - lower:
            raise RuntimeError("Debugger returned a short memory read")
        return {name: struct.unpack_from("<I", data, va - lower)[0]
                for name, va in symbols.items()}


async def connect_debugger(process):
    deadline = time.monotonic() + 25
    last_error = None
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"PPSSPP exited before debugger: {process.returncode}")
        try:
            return await websockets.connect("ws://127.0.0.1:8080/debugger",
                                            open_timeout=1, max_size=8 * 1024 * 1024,
                                            subprotocols=["debugger.ppsspp.org"],
                                            origin="http://localhost", proxy=None)
        except (OSError, TimeoutError, websockets.exceptions.InvalidHandshake) as error:
            last_error = str(error)
            await asyncio.sleep(0.1)
    raise TimeoutError(f"PPSSPP debugger did not start: {last_error}")


def terminate_owned(process):
    if process and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


async def run_case(args, run, length, symbols, exit_stub, display):
    name = "SampleApp" if length == 9 else "A" * length
    case = run / f"folder-{length:03d}"
    case.mkdir()
    xdg = case / "xdg-config"
    memstick = xdg / "ppsspp"
    target = memstick / "PSP" / "GAME" / name / "EBOOT.PBP"
    target.parent.mkdir(parents=True)
    with target.open("xb") as stream:
        stream.write(args.eboot.read_bytes())
    copied_sha = sha256(target)
    if copied_sha != args.expected_sha256:
        raise RuntimeError("Case copy differs from the pinned signed EBOOT")
    config = memstick / "PSP" / "SYSTEM" / "ppsspp.ini"
    config.parent.mkdir(parents=True)
    config.write_text("[General]\nFirstRun = False\nRemoteDebuggerOnStartup = True\n"
                      "RemoteDebuggerLocal = True\nRemoteISOPort = 8080\n"
                      "IgnoreBadMemAccess = False\nPauseWhenMinimized = False\n"
                      "CheckForNewVersion = False\n"
                      "[CPU]\nCPUCore = 0\n[Graphics]\nGraphicsBackend = 0\n"
                      "InternalResolution = 1\n[Sound]\nEnable = False\n"
                      "[SystemParam]\nPSPModel = 0\nPSPFirmwareVersion = 660\n",
                      encoding="ascii")
    env = dict(os.environ, DISPLAY=display, XDG_CONFIG_HOME=str(xdg),
               XDG_DATA_HOME=str(case / "xdg-data"),
               XDG_CACHE_HOME=str(case / "xdg-cache"),
               LIBGL_ALWAYS_SOFTWARE="1", SDL_AUDIODRIVER="dummy", SDL_VIDEODRIVER="x11")
    command = [str(args.emulator), "-i", "--windowed", "--graphics=gles",
               "--xres", "960", "--yres", "544", "--loglevel=3",
               f"--appendconfig={config}", str(target)]
    result = {"status": "FAIL", "scope": SCOPE, "started_utc": utc(),
              "folder_name": name, "folder_ascii_bytes": len(name.encode("ascii")),
              "eboot_sha256": copied_sha, "launch_command": command,
              "memstick": str(memstick), "xdg_config_home": str(xdg),
              "home_physical_callback": "NOT TESTED", "stock_ofw": "NOT TESTED",
              "publisher_32_ascii_policy": "PASS" if length <= 32 else "REFUSE"}
    process, ws = None, None
    with (case / "ppsspp.log").open("x", encoding="utf-8") as log, \
            (case / "debugger.jsonl").open("x", encoding="utf-8") as journal:
        try:
            process = subprocess.Popen(command, cwd=case, env=env,
                                       stdout=log, stderr=subprocess.STDOUT)
            ws = await connect_debugger(process)
            debugger = Debugger(ws, journal)
            result["debugger_version"] = await debugger.request(
                "version", name="psp-guide-runtime", version="1.0.0")
            result["game_at_start"] = await debugger.request("game.status")
            deadline = time.monotonic() + 20
            module = None
            while time.monotonic() < deadline:
                startup_status = await debugger.request("cpu.status")
                if not startup_status.get("pc"):
                    await asyncio.sleep(0.05)
                    continue
                reply = await debugger.request("hle.module.list")
                active = [m for m in reply.get("modules", [])
                          if m.get("name") == "SampleApp" and m.get("isActive")]
                if active:
                    if len(active) != 1:
                        raise RuntimeError("Ambiguous active SampleApp module")
                    module = active[0]
                    break
                await asyncio.sleep(0.1)
            if module is None:
                raise TimeoutError("SampleApp module was not active")
            result["module"] = module
            base = module["address"]
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                before = await debugger.snapshot(base, symbols)
                if before["sample_ready"] == 1:
                    break
                await asyncio.sleep(0.1)
            else:
                raise TimeoutError("sample_ready did not become 1")
            result["ready_snapshot"] = before
            await asyncio.sleep(0.35)
            after = await debugger.snapshot(base, symbols)
            result["advancing_snapshot"] = after
            if after["sample_heartbeat"] <= before["sample_heartbeat"]:
                raise RuntimeError("SampleApp heartbeat did not advance")
            if after["sample_exit_reason"] != 0:
                raise RuntimeError("SampleApp exited before controller input")
            result["running_cpu_status"] = await debugger.request("cpu.status")
            if length == 9:
                image_path = case / "ready-screen.png"
                ImageGrab.grab(xdisplay=display).save(image_path)
                result["screenshot"] = {"path": str(image_path.relative_to(run)),
                                        "sha256": sha256(image_path),
                                        "text_visual_review": "PENDING"}
            address = base + exit_stub
            result["exit_stub_address"] = address
            result["breakpoint_add"] = await debugger.request(
                "cpu.breakpoint.add", address=address, enabled=True)
            result["cross_down"] = await debugger.request(
                "input.buttons.send", buttons={"cross": True})
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline:
                status = await debugger.request("cpu.status")
                if status.get("stepping"):
                    break
                await asyncio.sleep(0.05)
            else:
                raise TimeoutError("CROSS did not reach the real exit import breakpoint")
            result["exit_cpu_status"] = status
            result["exit_pc_register"] = await debugger.request("cpu.getReg", name="pc")
            if result["exit_pc_register"].get("uintValue") != address:
                raise RuntimeError("CPU stopped away from the expected exit import")
            result["exit_snapshot"] = await debugger.snapshot(base, symbols)
            if result["exit_snapshot"]["sample_exit_reason"] != 2:
                raise RuntimeError("Controller did not set sample_exit_reason=2")
            result["cross_up"] = await debugger.request(
                "input.buttons.send", buttons={"cross": False})
            result["breakpoint_remove"] = await debugger.request(
                "cpu.breakpoint.remove", address=address)
            # The unmodified program now executes sceKernelExitGame through HLE.
            quit_events = sum(e.get("event") == "game.quit" for e in debugger.events)
            result["resume_exit_import"] = await debugger.request("cpu.resume", notification=True)
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline:
                if sum(e.get("event") == "game.quit" for e in debugger.events) > quit_events:
                    break
                await debugger.receive(max(0.01, deadline - time.monotonic()))
            else:
                raise TimeoutError("No game.quit after sceKernelExitGame")
            result["game_quit_events"] = [e for e in debugger.events if e.get("event") == "game.quit"]
            result["game_after_exit"] = await debugger.request("game.status")
            result["cpu_after_exit"] = await debugger.request("cpu.status")
            result["status"] = "PASS"
        except Exception as error:
            result["error"] = f"{type(error).__name__}: {error}"
            (case / "harness-error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        finally:
            if ws is not None:
                await ws.close()
            terminate_owned(process)
            result["emulator_process_returncode_after_cleanup"] = process.returncode if process else None
            result["finished_utc"] = utc()
    save_json(case / "result.json", result)
    print(f"folder ASCII bytes={length}: {result['status']}" +
          (f" ({result['error']})" if "error" in result else ""), flush=True)
    return result


async def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    run_dir = args.output.resolve()
    artifact_sha = sha256(args.eboot)
    if artifact_sha != args.expected_sha256:
        raise RuntimeError("Signed EBOOT SHA256 mismatch; refusing runtime test")
    with args.elf.open("rb") as stream:
        elf = ELFFile(stream)
        table = elf.get_section_by_name(".symtab")
        if table is None:
            raise RuntimeError("Matching linked ELF has no symbol table")
        values = {s.name: s["st_value"] for s in table.iter_symbols()
                  if s.name in GLOBALS or s.name == "sceKernelExitGame"}
    if set(values) != set(GLOBALS) | {"sceKernelExitGame"}:
        raise RuntimeError("Linked ELF is missing required diagnostic symbols")
    symbols = {key: values[key] for key in GLOBALS}
    prx = parse_prx(args.prx.read_bytes())
    exits = [i["stub_address"] + 8 * n
             for i in prx.imports if i["library"] == "LoadExecForUser"
             for n, nid in enumerate(i["nids"]) if nid == 0x05572A5F]
    if len(exits) != 1 or exits[0] != values["sceKernelExitGame"]:
        raise RuntimeError("PRX exit import and ELF symbol do not agree")
    report = {"schema": 1, "started_utc": utc(), "scope": SCOPE,
              "retake_reason": args.retake_reason,
              "signed_eboot_sha256": artifact_sha,
              "elf_sha256": sha256(args.elf), "raw_prx_sha256": sha256(args.prx),
              "main_source_sha256": sha256(args.source),
              "emulator": {"version": subprocess.check_output(
                  [str(args.emulator), "--version"], text=True).strip(),
                  "entrypoint_sha256": sha256(args.emulator),
                  "shared_payload_sha256": sha256(args.emulator.parents[1] / "shared/bin/PPSSPPSDL"),
                  "appimage_sha256": sha256(args.appimage),
                  "cpu_mode": "interpreter (-i)", "graphics": "Mesa software OpenGL/GLES",
                  "emulated_model": "PSP-1000 (PSPModel=0)",
                  "firmware_setting": "660; emulator setting only"},
              "environment": {"python": sys.version, "platform": platform.platform(),
                              "dependencies": {n: importlib.metadata.version(n)
                                               for n in ("websockets", "pyelftools", "Pillow")}},
              "symbol_offsets": symbols, "exit_import_offset": exits[0],
              "hardware_stock_ofw": "NOT TESTED", "physical_home_callback": "NOT TESTED",
              "publisher_folder_rule": "1–32 ASCII bytes; publisher policy, not a Sony limit",
              "folder_test_route": "Cold direct package launch by owned PSP/GAME/<name>/EBOOT.PBP path",
              "protocol_sources": [
                  "https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Debugger/WebSocket/InputSubscriber.cpp",
                  "https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Debugger/WebSocket/MemorySubscriber.cpp",
                  "https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Debugger/WebSocket/HLESubscriber.cpp",
                  "https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Debugger/WebSocket/CPUCoreSubscriber.cpp"],
              "cases": []}
    display = ":91"
    with (run_dir / "xvfb.log").open("x", encoding="utf-8") as xvfb_log:
        xvfb = subprocess.Popen(["Xvfb", display, "-screen", "0", "960x544x24", "-nolisten", "tcp"],
                                stdout=xvfb_log, stderr=subprocess.STDOUT)
        try:
            for _ in range(50):
                if xvfb.poll() is not None:
                    raise RuntimeError("Owned Xvfb failed to start")
                probe = subprocess.run(["xdpyinfo", "-display", display],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if probe.returncode == 0:
                    break
                await asyncio.sleep(0.1)
            else:
                raise TimeoutError("Owned Xvfb was not ready")
            for length in args.lengths:
                report["cases"].append(await run_case(args, run_dir, length, symbols, exits[0], display))
        finally:
            terminate_owned(xvfb)
    report["finished_utc"] = utc()
    report["status"] = "PASS" if all(c["status"] == "PASS" for c in report["cases"]) else "FAIL"
    report["interpretation"] = (
        "Measured directory lengths describe this emulator direct-launch route only. "
        "Lengths above32 deliberately bypass publisher release policy for diagnosis. "
        "Heartbeat, memory sizes and exit observations are emulator measurements, not hardware values. "
        "No latency, speedup, leak freedom or long-run stability is inferred.")
    save_json(run_dir / "report.json", report)
    return 0 if report["status"] == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eboot", type=Path, default=Path("/lab/build-a/EBOOT-signed.PBP"))
    parser.add_argument("--elf", type=Path, default=Path("/lab/build-a/SampleApp.elf"))
    parser.add_argument("--prx", type=Path, default=Path("/lab/build-a/SampleApp.prx"))
    parser.add_argument("--source", type=Path, default=Path("/lab/source/sample/main.c"))
    parser.add_argument("--emulator", type=Path, default=Path("/emulator/AppDir/bin/PPSSPPSDL"))
    parser.add_argument("--appimage", type=Path, default=Path("/emulator/PPSSPP-v1.20.4-anylinux-x86_64.AppImage"))
    parser.add_argument("--expected-sha256", default=EXPECTED_EBOOT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lengths", type=int, nargs="+", default=[1, 9, 31, 32, 33, 64])
    parser.add_argument("--retake-reason", default=None,
                        help="Technical reason for a retake; earlier output must remain preserved")
    args = parser.parse_args()
    if not args.lengths or len(set(args.lengths)) != len(args.lengths) or any(n < 1 or n > 127 for n in args.lengths):
        parser.error("Use unique ASCII folder lengths in 1..127")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with (args.output.parent / ".runtime.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return asyncio.run(run(args))


if __name__ == "__main__":
    raise SystemExit(main())
