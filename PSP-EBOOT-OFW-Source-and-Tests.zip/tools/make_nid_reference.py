#!/usr/bin/env python3
"""Generate a selected-public-user-source reference from the pinned SDK checkout."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse,json
from pspguide.nids import generate_map

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("sdk",type=Path);p.add_argument("output",type=Path);a=p.parse_args()
    result=generate_map(a.sdk)
    with a.output.open("x",encoding="utf-8") as stream:stream.write(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":"PASS","functions":len(result["functions"]),"source_files":len(result["source_files"]),"sdk_revision":result["sdk_revision"]}))
if __name__=="__main__":raise SystemExit(main())
