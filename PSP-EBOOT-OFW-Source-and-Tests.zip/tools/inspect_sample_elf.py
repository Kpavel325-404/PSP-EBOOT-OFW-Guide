#!/usr/bin/env python3
"""Second-parser inspection of linked main-thread/heap parameters and symbols."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
import json
import struct
from elftools.elf.elffile import ELFFile
from pspguide.formats import need


def inspect(path):
    with Path(path).open('rb') as stream:
        elf=ELFFile(stream);table=elf.get_section_by_name('.symtab')
        need(table is not None,'Linked ELF symbol table needed for parameter audit')
        symbols={symbol.name:int(symbol['st_value']) for symbol in table.iter_symbols() if symbol.name}
        def value(name):
            need(name in symbols,'Missing parameter '+name);address=symbols[name]
            matches=[p for p in elf.iter_segments() if p['p_type']=='PT_LOAD'
                     and p['p_vaddr']<=address and address+4<=p['p_vaddr']+p['p_filesz']]
            need(len(matches)==1,'Parameter file mapping');segment=matches[0]
            stream.seek(segment['p_offset']+address-segment['p_vaddr'])
            return struct.unpack('<I',stream.read(4))[0]
        params={name:value(name) for name in ['sce_newlib_attribute','sce_newlib_stack_kb_size','sce_newlib_heap_kb_size']}
        need(params['sce_newlib_attribute']==0x80000000,'Linked USER main-thread parameter')
        need(params['sce_newlib_stack_kb_size']==32,'Linked32KiB stack parameter')
        need(params['sce_newlib_heap_kb_size']==2048,'Linked2MiB heap parameter')
        return dict(status='PASS',parser='pyelftools',ELF_class=elf.elfclass,
                    machine=elf.header['e_machine'],entry=int(elf.header['e_entry']),
                    parameters=params,symbols={k:v for k,v in symbols.items() if k.startswith('sample_')},
                    physical_OFW='NOT TESTED')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('elf',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    result=inspect(a.elf)
    with a.report.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
