#!/usr/bin/env python3
"""Sign one audited SampleApp snapshot; original and existing outputs are never overwritten."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
from pspguide.sign import safe_sign
from _cli import run

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("input",type=Path);p.add_argument("output",type=Path)
    p.add_argument("--signer",type=Path,required=True);p.add_argument("--signer-sha256",required=True)
    p.add_argument("--sources",type=Path,required=True);p.add_argument("--nid-map",type=Path,required=True)
    p.add_argument("--report",type=Path);a=p.parse_args()
    return run(lambda:safe_sign(a.input,a.output,a.signer,a.signer_sha256,a.sources,a.nid_map),a)
if __name__=="__main__":raise SystemExit(main())
