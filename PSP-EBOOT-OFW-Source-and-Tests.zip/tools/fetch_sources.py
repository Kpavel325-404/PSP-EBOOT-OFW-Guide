#!/usr/bin/env python3
"""Fetch exact public source archives without shipping their mixed-license code.

Checks archive SHA256 before parsing and every approved file before writing.
--check-existing verifies cached source files without another download.
"""
from pathlib import Path,PurePosixPath
import argparse
import hashlib
import io
import json
import tarfile
import urllib.request


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('destination',type=Path);p.add_argument('--check-existing',action='store_true');a=p.parse_args()
    project=Path(__file__).resolve().parents[1]
    archives=json.loads((project/'references/upstream-pins.json').read_text())
    file_pins=json.loads((project/'references/source-file-pins.json').read_text())
    reports=[]
    for entry in archives:
        name=entry['name'];target=a.destination/name;expected=file_pins[name]
        if not a.check_existing:
            if target.exists():raise ValueError('Refusing existing source directory: '+str(target))
            with urllib.request.urlopen(entry['archive_url'],timeout=60) as stream:
                payload=stream.read(32*1024*1024+1)
            if len(payload)>32*1024*1024 or hashlib.sha256(payload).hexdigest()!=entry['archive_sha256']:
                raise ValueError('Pinned source archive size/hash mismatch: '+name)
            contents={}
            with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
                for member in archive:
                    if member.isdir():continue
                    parts=PurePosixPath(member.name).parts
                    if len(parts)<2 or '..' in parts or member.name.startswith('/') or not member.isfile():
                        raise ValueError('Unsafe archive member')
                    relative=PurePosixPath(*parts[1:]).as_posix()
                    if relative not in expected or relative in contents or member.size>8*1024*1024:
                        raise ValueError('Unexpected/oversized source member')
                    data=archive.extractfile(member).read()
                    if hashlib.sha256(data).hexdigest()!=expected[relative]:raise ValueError('Source file hash mismatch')
                    contents[relative]=data
            if set(contents)!=set(expected):raise ValueError('Incomplete source archive')
            target.mkdir(parents=True,exist_ok=False)
            for relative,data in contents.items():
                path=target/relative;path.parent.mkdir(parents=True,exist_ok=True)
                with path.open('xb') as stream:stream.write(data)
        for relative,wanted in expected.items():
            file=target/relative
            if file.is_symlink() or hashlib.sha256(file.read_bytes()).hexdigest()!=wanted:
                raise ValueError('Cached pinned source changed: '+relative)
        reports.append(dict(repository=name,revision=entry['revision'],source_files=len(expected),status='PASS'))
    print(json.dumps({'status':'PASS','sources':reports},indent=2))


if __name__=='__main__':main()
