#!/usr/bin/env python3
"""Create a NEW ZIP with all staging files, root documentation and checksums."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
from pspguide.release import fresh_zip
from _cli import run

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("staging",type=Path);p.add_argument("output",type=Path)
    p.add_argument("--report",type=Path);a=p.parse_args()
    return run(lambda:fresh_zip(a.staging,a.output),a)
if __name__=="__main__":raise SystemExit(main())
