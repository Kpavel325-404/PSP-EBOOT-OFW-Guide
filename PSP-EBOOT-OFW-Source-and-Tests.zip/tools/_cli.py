"""Shared CLI reporting; never overwrites an existing report or artifact."""
import json
from pathlib import Path
from pspguide.formats import FormatError

def emit(result, report=None):
    text=json.dumps(result,indent=2)+"\n"
    if report:
        with Path(report).open("x",encoding="utf-8") as stream:stream.write(text)
    print(text,end="")

def run(function,args):
    # Reserve a new report before any operation can publish an artifact. An
    # existing/unwritable report path must not cause a late failure after sign
    # or package has already created its destination.
    stream=None
    try:
        report=getattr(args,"report",None)
        output=getattr(args,"output",None)
        if report is not None and output is not None and Path(report).resolve()==Path(output).resolve():
            raise ValueError("Report/output alias is forbidden")
        if report is not None:stream=Path(report).open("x",encoding="utf-8")
        result=function()
        code=0 if result.get("status")=="PASS" else 2
    except (OSError,ValueError,TimeoutError) as exc:
        result={"status":"FAIL","error":str(exc),"physical_OFW":"NOT TESTED"}
        code=1
    try:
        text=json.dumps(result,indent=2)+"\n"
        if stream is not None:stream.write(text);stream.flush()
        print(text,end="")
    except OSError as exc:
        print(json.dumps({"status":"FAIL","error":"Report I/O: "+str(exc),
                          "physical_OFW":"NOT TESTED"}))
        code=1
    finally:
        if stream is not None:stream.close()
    return code
