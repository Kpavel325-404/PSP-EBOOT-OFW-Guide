#!/usr/bin/env python3
"""Inventory a plaintext PRX; VERIFIED is a pinned SDK mapping, not an OFW result."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
from pspguide.formats import parse_prx,parse_pbp
from pspguide.sign import read_limited
from pspguide.nids import inventory,load_map
from _cli import emit

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("input",type=Path);p.add_argument("--nid-map",type=Path,required=True)
    p.add_argument("--report",type=Path);a=p.parse_args()
    try:
        data=read_limited(a.input)
        if data[:4]==b"\0PBP":data=parse_pbp(data).sections[6]
        result=inventory(parse_prx(data),load_map(a.nid_map));emit(result,a.report)
        return {"VERIFIED":0,"UNKNOWN":2,"UNSUPPORTED":3}[result["status"]]
    except (OSError,ValueError) as exc:
        emit({"status":"FAIL","error":str(exc),"physical_OFW":"NOT TESTED"});return 1
if __name__=="__main__":raise SystemExit(main())
