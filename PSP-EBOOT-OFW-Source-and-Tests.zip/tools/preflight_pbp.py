#!/usr/bin/env python3
"""Bounded SampleApp preflight; successful parsing is not an OFW launch."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import argparse
from pspguide.formats import validate_unsigned
from pspguide.sign import read_limited
from pspguide.verify import digest
from pspguide.nids import load_map,inventory,require_user_profile
from _cli import run

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("input",type=Path);p.add_argument("--nid-map",type=Path,required=True)
    p.add_argument("--report",type=Path);a=p.parse_args()
    def work():
        snapshot=read_limited(a.input)
        c,prx,sfo=validate_unsigned(snapshot)
        imports=inventory(prx,load_map(a.nid_map));require_user_profile(imports)
        return dict(status="PASS",scope="SampleApp structural/SFO/user-import profile",input_sha256=digest(snapshot),raw_prx_sha256=digest(prx.data),raw_prx_bytes=len(prx.data),SFO=sfo,imports=imports,physical_OFW="NOT TESTED")
    return run(work,a)
if __name__=="__main__":raise SystemExit(main())
