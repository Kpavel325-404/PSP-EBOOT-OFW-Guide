#!/usr/bin/env python3
"""Build the complete selectable-text guide, with an identical ZIP attachment.

Run using requirements-document.txt. All measured tables are generated from
saved evidence; this program never builds or runs PSP software.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import json
from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph,
    Spacer, PageBreak, NextPageTemplate, LongTable, TableStyle, KeepTogether,
    Preformatted, Flowable)
from reportlab.platypus.tableofcontents import TableOfContents
from pypdf import PdfReader, PdfWriter
from pypdf.generic import TextStringObject

ROOT=Path(__file__).resolve().parents[1]
TITLE='PSP EBOOT: Building for Official Firmware & Paranoid Cross-Validation'
NAVY=colors.HexColor('#142D43'); TEAL=colors.HexColor('#007F82')
INK=colors.HexColor('#203344'); MUTED=colors.HexColor('#526779')
PALE=colors.HexColor('#EDF5F5'); LINE=colors.HexColor('#CCDADD')
W,H=A4; M=48; CW=W-2*M


def load(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dynamic():
    repro=load('evidence/reproducibility.json')
    sign=load('evidence/sample-signed-a.json')
    runtime=load('evidence/runtime/attempt-005/report.json')
    artifact_rows=['| Artifact | Bytes | A/B identity |','| --- | --- | --- |']
    for row in repro['artifacts']:
        c=row['copies'][0]
        artifact_rows.append(f"| {row['artifact']} | {c['bytes']:,} | {'PASS' if row['identical'] else 'FAIL'} |")
    artifact_rows += ['', 'Full SHA-256 identities (both builds):','']
    for row in repro['artifacts']:
        artifact_rows += [f"**{row['artifact']}**",'','```text',row['copies'][0]['sha256'],'```','']
    artifact_rows += [
      '| Measured field | Value | Scope |','| --- | --- | --- |',
      f"| Plaintext PRX | {sign['raw_prx_bytes']:,} bytes | Build A and B |",
      f"| Signed DATA.PSP | {sign['signed_DATA_PSP_bytes']:,} bytes | Fixed-format body in actual output |",
      f"| File-backed LOAD storage | {sign['file_backed_LOAD_bytes']:,} bytes | Static binary analysis |",
      f"| Static LOAD memory | {sign['static_LOAD_memory_bytes']:,} bytes | Static binary analysis; excludes heap/stacks |",
      f"| Type-7 relocation changes | {sign['relocations_changed']} | Actual input |",
      '| Imports | 12 libraries / 54 functions | All mapped to selected SDK user stubs |',
      '| Inner module / main thread | 0 / 0x80000000 | Module profile / linked USER thread attribute |',
      '| Linked stack / heap request | 32 KiB / 2,048 KiB | pyelftools parameter audit |',
      '| SFO memory / version | MEMSIZE=0 / PSP_SYSTEM_VER=6.60 | Typed metadata, not compatibility |',
      '| Physical peak RAM / CPU / FPS | NOT MEASURED | No physical run |',
      '',
      'The generated SFO also contains DISC_ID=UCJS10041, DISC_VERSION=1.00, PARENTAL_LEVEL=1 and REGION=32768. These are SDK generator defaults, not an assigned Sony publishing identity for this example. All generated SFO bytes are retained.',
      '',
      'The final PSPDEV-derived image identity, exact tool hashes, linked parameters and source hashes are in environment/build-manifest.json. The source revision of the SDK installed inside the base image is UNKNOWN; the reference checkout pins describe source review, not a claim about that installed SDK revision.',
    ]
    matrix=['| Executed check or open case | Result | Evidence / boundary |','| --- | --- | --- |',
      '| Final native host parser, crypto, NID and safety suite | PASS: 38 / 38 | host-final.log; original32-test run and noexec error retained |',
      '| Real-artifact negative CLI controls | PASS: 13 / 13 | negative/summary.json; expected rejections retain FAIL reports |',
      '| Two independent build directories | PASS: 4 / 4 identical artifacts | reproducibility.json; also SFO comparison in build manifest |',
      '| Isolated signer A and B | PASS | Exact input/tool hashes; original snapshots unchanged |',
      '| Separate crypto/profile CLI | PASS | sample-independent-cli.json |',
      '| Linked ELF parameter audit | PASS | linked-elf.json; parser independent of guide PRX parser |',
      '| Cold PPSSPP direct launches | PASS: 6 / 6 | attempt-005/report.json; same signed hash |',
      '| Live input and exit in PPSSPP | PASS: 6 / 6 | CROSS -> reason 2 -> exit import -> game.quit |',
      '| Physical PSP stock OFW 6.60 / 6.61 | NOT TESTED | All five physical families |',
      '| Physical XMB / HOME / suspend-resume | NOT TESTED | No physical observation |',
      '| Physical peak RAM / sustained performance | NOT MEASURED | No physical profiling |',
      '| Target firmware exports / attribute acceptance | UNKNOWN | SDK mapping is insufficient |',
      '',
      'PPSSPP 1.20.4 ran in interpreter mode with software Mesa and emulated PSPModel=0. Each cold run observed SampleApp ready=1, an advancing heartbeat, and the same EBOOT hash. The debugger sent CROSS, observed exit_reason=2 at the real exit import (0x08820B28), then observed game.quit and a stopped CPU. This tests the application exit path; the physical HOME callback remains NOT TESTED.',
      '',
      '| ASCII folder bytes | Direct-launch result | Publisher rule |','| --- | --- | --- |']
    for c in runtime['cases']:
        matrix.append(f"| {c['folder_ascii_bytes']} | {c['status']} in PPSSPP only | {'Admit' if c['folder_ascii_bytes']<=32 else 'Refuse'} |")
    matrix += ['',
      'Names were A, SampleApp, then repeated A for the other lengths. The 33- and 64-byte diagnostic paths deliberately bypass the publisher rule. None of these direct launches tests Sony XMB directory discovery or establishes a Sony name-length limit.',
      '',
      '| Emulator-only ready snapshot | Bytes |','| --- | --- |',
      '| Total free memory | 22,865,408 |','| Largest free block | 22,603,264 |','| GE-reported memory | 2,097,152 |',
      '',
      'These are observed emulator values for this build and configuration, not physical PSP specifications, application peak use, leak tests or performance results.',
      '',
      'Earlier runtime attempts 001-004 remain FAIL in the evidence. They exposed debugger discovery/configuration, startup timing and an incorrect expectation of a ticketed cpu.resume response. Attempt 004 already reached the live application exit path; the harness timed out afterward. The corrected harness in attempt 005 awaits the documented asynchronous event. SampleApp was unchanged. The host suite also retains its initial noexec-fixture ERROR and the corrected 32-test run. See evidence/runtime/README.md for the chronology.',
      '',
      'After the saved runs, the CLI report-path review added focused regression tests. All six focused tests and the complete 38-test suite passed; see evidence/cli-regression-final.log, evidence/host-final.log and TECHNICAL_AUDIT.md. The findings and their regression failures are preserved. They do not replace or erase the original 32-test evidence.',
    ]
    return {'SAMPLE_MAIN':'```c\n'+(ROOT/'sample/main.c').read_text()+'```',
      'SAMPLE_MAKEFILE':'```make\n'+(ROOT/'sample/Makefile').read_text()+'```',
      'COMMANDS':(ROOT/'document/lab-commands.md').read_text(encoding='utf-8'),
      'MEASURED_RESULTS':'\n'.join(artifact_rows), 'EVIDENCE_MATRIX':'\n'.join(matrix)}


class Diagram(Flowable):
    def __init__(self,kind):
        super().__init__();self.kind=kind;self.width=CW;self.height=157 if kind=='validation' else 144
    def draw(self):
        c=self.canv;c.setFillColor(PALE);c.roundRect(0,0,self.width,self.height,7,fill=1,stroke=0)
        c.setFillColor(TEAL);c.setFont('BodyBold',9)
        title={'validation':'EVIDENCE BOUNDARIES','boot':'APPLICATION LOADING: AN INTEGRATION VIEW','memory':'A BUDGET IS MORE THAN A FILE SIZE'}[self.kind]
        c.drawString(13,self.height-22,title)
        if self.kind=='memory':
            blocks=[('Static LOAD','153,988 B measured'),('Heap request','2,048 KiB linked'),('Stack request','32 KiB linked')]
            note=['Add worker stacks, runtime/service allocations and a safety reserve.',
                  'Graphics capacity is separate: query and budget actual buffers.',
                  'No physical peak-use or available-RAM claim is made.']
        elif self.kind=='boot':
            blocks=[('Storage / PBP','Discovery and metadata'),('Loader / PRX','Policy, imports, relocation'),('Application','Initialize, run, exit')]
            note=['Public SDK interfaces describe boundaries; private Sony loader policy',
                  'is not fully specified here. Record the furthest observed stage.',
                  'Menu recognition, code entry and correct behavior are different checks.']
        else:
            blocks=[('Offline checks','Structure + crypto'),('Emulator','Modeled behavior'),('Physical device','Model + stock firmware')]
            note=['PASS stays attached to its own check and artifact hash.',
                  'A result at one boundary does not fill another boundary with PASS.',
                  'Physical stock OFW in this laboratory: NOT TESTED.']
        bw=(self.width-48)/3; y=self.height-78
        for i,(a,b) in enumerate(blocks):
            x=12+i*(bw+12);c.setFillColor(colors.white);c.roundRect(x,y,bw,38,4,fill=1,stroke=0)
            c.setFillColor(NAVY);c.setFont('BodyBold',8.1);c.drawString(x+8,y+23,a)
            c.setFillColor(MUTED);c.setFont('Body',7.4);c.drawString(x+8,y+10,b)
        c.setFillColor(INK);c.setFont('Body',8.1)
        for i,line in enumerate(note):c.drawString(13,y-17-i*13,line)


class Guide(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=M,rightMargin=M,topMargin=49,bottomMargin=45,
            title=TITLE,author='Community engineering laboratory',pageCompression=1,
            allowSplitting=1)
        self.active_chapter='';self.heading_map=[]
        frame=Frame(M,45,CW,H-94,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
        self.addPageTemplates([PageTemplate(id='Cover',frames=[frame],onPage=self.coverpage),
                              PageTemplate(id='Body',frames=[frame],onPage=self.bodypage)])
    def coverpage(self,c,doc):
        c.setFillColor(NAVY);c.rect(0,0,W,H,fill=1,stroke=0)
        c.setFillColor(TEAL);c.rect(0,H-13,W,13,fill=1,stroke=0)
        c.setStrokeColor(colors.HexColor('#30495C'));c.setLineWidth(0.8)
        for x in range(30,600,35):c.line(x,0,x+230,230)
    def bodypage(self,c,doc):
        c.saveState();c.setFillColor(MUTED);c.setFont('Body',7.3)
        c.drawString(M,H-29,'PSP EBOOT / OFW  •  ENGINEERING LABORATORY')
        c.setStrokeColor(LINE);c.line(M,H-36,W-M,H-36)
        c.line(M,34,W-M,34);c.setFont('Body',7.3)
        c.drawString(M,21,'Offline evidence and emulator observations; physical stock OFW: NOT TESTED')
        c.setFont('BodyBold',8);c.drawRightString(W-M,21,str(doc.page));c.restoreState()
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and hasattr(f,'_toc'):
            level,text,key=f._toc
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text,key,level=level,closed=False)
            self.notify('TOCEntry',(level,text,self.page,key))
            self.heading_map.append({'level':level,'title':text,'page':self.page,'key':key})


def styles():
    fontdir=ROOT/'document/fonts'
    for name,file in [('Body','DejaVuSans.ttf'),('BodyBold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf'),('MonoBold','DejaVuSansMono-Bold.ttf')]:
        pdfmetrics.registerFont(TTFont(name,str(fontdir/file)))
    pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')
    pdfmetrics.registerFontFamily('Mono',normal='Mono',bold='MonoBold',italic='Mono',boldItalic='MonoBold')
    s={}
    s['p']=ParagraphStyle('P',fontName='Body',fontSize=9.4,leading=13.0,textColor=INK,spaceAfter=6.5,splitLongWords=1,allowWidows=0,allowOrphans=0)
    s['tight']=ParagraphStyle('Tight',parent=s['p'],leading=12.5,spaceAfter=6)
    s['h2']=ParagraphStyle('H2',parent=s['p'],fontName='BodyBold',fontSize=22,leading=27,textColor=NAVY,spaceAfter=17,keepWithNext=True)
    s['h3']=ParagraphStyle('H3',parent=s['p'],fontName='BodyBold',fontSize=12.2,leading=17,textColor=TEAL,spaceBefore=11,spaceAfter=7,keepWithNext=True)
    s['cell']=ParagraphStyle('Cell',parent=s['p'],fontSize=7.7,leading=11.2,spaceAfter=0)
    s['th']=ParagraphStyle('TH',parent=s['cell'],fontName='BodyBold',textColor=colors.white)
    s['list']=ParagraphStyle('List',parent=s['p'],leftIndent=15,firstLineIndent=0,bulletIndent=1,spaceAfter=5)
    s['code']=ParagraphStyle('Code',fontName='Mono',fontSize=7.05,leading=10.4,textColor=INK,spaceBefore=6,spaceAfter=10,borderColor=LINE,borderWidth=.5,borderPadding=9,backColor=colors.HexColor('#F4F7F9'))
    return s


def inline(text):
    # Protect URLs/code before escaping other text; all input is owned Markdown.
    parts=[]
    def store(x):parts.append(x);return f'ZXQ{len(parts)-1}QXZ'
    text=re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)',lambda m:store('<link href="'+html.escape(m[2],quote=True)+'" color="#007F82">'+escape(m[1])+'</link>'),text)
    text=re.sub(r'`([^`]+)`',lambda m:store('<font name="Mono" size="8.3">'+escape(m[1])+'</font>'),text)
    text=escape(text)
    text=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',text)
    for i,p in enumerate(parts):text=text.replace(f'ZXQ{i}QXZ',p)
    return text


def table(rows,s,dense=False):
    count=len(rows[0]);widths=[CW/count]*count
    padding=4.5 if dense else 6
    headers=' '.join(rows[0]).lower()
    if count==2:widths=[CW*.29,CW*.71]
    if 'primary source' in headers:widths=[CW*.08,CW*.92]
    if count==3:widths=[CW*.30,CW*.25,CW*.45]
    if count==4:widths=[CW*.18,CW*.17,CW*.43,CW*.22]
    if 'tool and pin' in headers:widths=[CW*.25,CW*.25,CW*.27,CW*.23]
    if 'library' in headers and 'nid' in headers:widths=[CW*.21,CW*.18,CW*.40,CW*.21]
    data=[[Paragraph(inline(v.strip()),s['th'] if r==0 else s['cell']) for v in row] for r,row in enumerate(rows)]
    t=LongTable(data,colWidths=widths,repeatRows=1,hAlign='LEFT',spaceBefore=6,spaceAfter=12)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F6F7')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),('LINEBELOW',(0,0),(-1,0),.8,TEAL),('LINEBELOW',(0,-1),(-1,-1),.5,LINE)]))
    return t


def parse_md(text,s):
    lines=text.splitlines();story=[];i=0;hn=0;chapter=''
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('```'):
            code=[];i+=1
            while i<len(lines) and not lines[i].strip().startswith('```'):code.append(lines[i].expandtabs(4));i+=1
            # Code width is measured, not silently truncated or resized to unreadability.
            maxwidth=CW-22
            for cl in code:
                if pdfmetrics.stringWidth(cl,'Mono',7.05)>maxwidth:
                    raise ValueError('Code line exceeds available width: '+cl)
            story.append(Preformatted('\n'.join(code),s['code']));i+=1;continue
        d=re.fullmatch(r'\{\{DIAGRAM:(\w+)\}\}',line)
        if d:story.extend([Spacer(1,5),Diagram(d[1]),Spacer(1,12)]);i+=1;continue
        if line.startswith('## '):
            if story:story.append(PageBreak())
            title=line[3:];chapter=title;p=Paragraph(inline(title),s['h2']);p._toc=(0,title,f'h{hn}');hn+=1;story.append(p);i+=1;continue
        if line.startswith('### '):
            title=line[4:];p=Paragraph(inline(title),s['h3']);p._toc=(1,title,f'h{hn}');hn+=1;story.append(p);i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=lines[i].strip().strip('|').split('|')
                if not all(re.fullmatch(r'\s*:?-+:?\s*',x) for x in cells):rows.append(cells)
                i+=1
            if len({len(x) for x in rows})!=1:raise ValueError('Unequal Markdown table width')
            story.append(table(rows,s,dense=chapter.startswith('Primary Sources')));continue
        m=re.match(r'^(\d+)\.\s+(.+)',line)
        if m or line.startswith('- '):
            bullet=m[1]+'.' if m else '•';content=m[2] if m else line[2:]
            story.append(Paragraph(inline(content),s['list'],bulletText=bullet));i+=1;continue
        para=[line];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||```|\{\{|\d+\.\s|- )',lines[i].strip()):
            para.append(lines[i].strip());i+=1
        story.append(Paragraph(inline(' '.join(para)),s['tight'] if chapter.startswith(('Chapter 6 ', 'Primary Sources')) else s['p']))
    return story


def build(output,companion,work):
    s=styles();md=(ROOT/'document/chapters.md').read_text(encoding='utf-8')
    for token,value in dynamic().items():
        marker='{{'+token+'}}'
        if md.count(marker)!=1:raise ValueError('Missing/duplicate marker '+marker)
        md=md.replace(marker,value)
    if re.search(r'\{\{(?!DIAGRAM:)',md):raise ValueError('Unresolved content marker')
    work.mkdir(parents=True,exist_ok=True)
    (work/'assembled.md').write_text(md,encoding='utf-8')
    cover_title=ParagraphStyle('CoverTitle',fontName='BodyBold',fontSize=34,leading=42,textColor=colors.white)
    cover_sub=ParagraphStyle('CoverSub',fontName='Body',fontSize=12,leading=19,textColor=colors.HexColor('#D7E5EA'))
    cover_label=ParagraphStyle('CoverLabel',fontName='BodyBold',fontSize=10,leading=16,textColor=colors.HexColor('#73D8CF'))
    story=[Spacer(1,53),Paragraph('COMMUNITY ENGINEERING GUIDE',cover_label),Spacer(1,22),
      Paragraph('PSP EBOOT:',cover_title),Spacer(1,8),
      Paragraph('Building for Official Firmware &amp; Paranoid Cross-Validation',cover_title),Spacer(1,32),
      Paragraph('Understand the format. Protect the original.<br/>Build, sign and verify a complete SampleApp.',cover_sub),Spacer(1,32),
      Paragraph('THREE PRACTICAL LABORATORIES',cover_label),Spacer(1,9),
      Paragraph('Safe Signing Laboratory<br/>PRX / NID Auditor<br/>Reproducible SampleApp Laboratory',cover_sub),Spacer(1,36),
      Paragraph('Target metadata: OFW 6.60 / 6.61 investigation<br/>Offline validation and PPSSPP evidence supplied.<br/><b>Physical stock OFW: NOT TESTED.</b>',cover_sub),
      NextPageTemplate('Body'),PageBreak(),Paragraph('Contents',s['h2'])]
    toc=TableOfContents();toc.levelStyles=[
      ParagraphStyle('TOC0',fontName='BodyBold',fontSize=9.1,leading=13.5,textColor=NAVY,spaceBefore=11,rightIndent=24),
      ParagraphStyle('TOC1',fontName='Body',fontSize=8.2,leading=12,textColor=INK,leftIndent=13,rightIndent=24,spaceBefore=1)]
    story += [toc,PageBreak()]+parse_md(md,s)
    draft=work/'guide-body.pdf';doc=Guide(draft);doc.multiBuild(story)
    if output.exists():raise ValueError('Refusing existing final PDF destination')
    reader=PdfReader(draft);writer=PdfWriter(clone_from=reader)
    writer.add_metadata({'/Title':TITLE,'/Author':'Community engineering laboratory','/Subject':'PSP PBP, SFO, PRX, safe signing and evidence-scoped validation'})
    attachment=writer.add_attachment(companion.name,companion.read_bytes())
    attachment.description=TextStringObject('Complete tested companion; identical to the external source-and-tests ZIP.')
    writer.write(output)
    links=[]
    final=PdfReader(output)
    for n,page in enumerate(final.pages,1):
        for ref in page.get('/Annots',[]):
            obj=ref.get_object();act=obj.get('/A',{})
            if act.get('/URI'):links.append({'page':n,'uri':str(act['/URI'])})
    report={'status':'PASS','title':TITLE,'pages':len(final.pages),'pdf_sha256':sha(output),
      'companion_sha256':sha(companion),'attachment_name':companion.name,'external_links':links,
      'headings':doc.heading_map[-sum(1 for x in md.splitlines() if x.startswith(('## ','### '))):],
      'source_main_sha256':sha(ROOT/'sample/main.c'),'source_makefile_sha256':sha(ROOT/'sample/Makefile'),
      'physical_stock_ofw':'NOT TESTED','scope':'Generation only; rendered-page visual review is separate.'}
    (work/'pdf-build.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','pages','pdf_sha256','companion_sha256']}))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--companion',type=Path,required=True);p.add_argument('--work',type=Path,required=True)
    a=p.parse_args();build(a.output,a.companion,a.work)
