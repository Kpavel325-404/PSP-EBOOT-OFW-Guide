#!/usr/bin/env python3
"""Render every page and record text, link, attachment and geometry checks."""
import argparse
import hashlib
import json
from pathlib import Path
from pypdf import PdfReader
import pypdfium2 as pdfium
from PIL import Image, ImageDraw, ImageFont


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('pdf',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--companion',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    reader=PdfReader(a.pdf);doc=pdfium.PdfDocument(a.pdf)
    text=[];pages=[];uris=[];internal=[];bad=[]
    ids={page.indirect_reference.idnum:i+1 for i,page in enumerate(reader.pages)}
    for i,page in enumerate(reader.pages):
        t=page.extract_text();text.append(t)
        for ref in page.get('/Annots',[]):
            ann=ref.get_object();act=ann.get('/A',{})
            if act.get('/URI'):uris.append(str(act['/URI']))
            dest=ann.get('/Dest',act.get('/D'))
            if dest is not None:
                if hasattr(dest,'get_object'):dest=dest.get_object()
                if isinstance(dest,list):
                    target=getattr(dest[0],'idnum',None);valid=target in ids
                    internal.append({'from':i+1,'to':ids.get(target),'valid':valid})
                    if not valid:bad.append({'page':i+1,'reason':'broken internal link'})
        pp=doc[i];tp=pp.get_textpage();w,h=pp.get_size();outside=[]
        for k in range(tp.count_chars()):
            left,bottom,right,top=tp.get_charbox(k)
            if left < -0.5 or bottom < -0.5 or right>w+.5 or top>h+.5:
                outside.append(k)
        if outside:bad.append({'page':i+1,'reason':'out-of-page text','characters':len(outside)})
        image=pp.render(scale=1.5).to_pil();path=a.output/f'page-{i+1:03}.png';image.save(path)
        pages.append({'page':i+1,'text_chars':len(t),'rendered':path.name,
          'render_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'text_outside_page':len(outside)})
        tp.close();pp.close()
    full='\n\n'.join(text);(a.output/'full-text.txt').write_text(full,encoding='utf-8')
    if '{{' in full or '\ufffd' in full:bad.append({'reason':'marker/replacement glyph in text'})
    # This known owned ZIP may exceed pypdf's default75,000,000-byte
    # declared-stream policy. Increase only to its exact expected size, with
    # our own128MiB ceiling, then restore the library setting. No unlimited
    # decompression policy or system-library patch is used.
    import pypdf.filters as filters
    expected_size=a.companion.stat().st_size
    if expected_size>128*1024*1024:raise ValueError('Owned companion exceeds128MiB inspection policy')
    prior_limit=filters.MAX_DECLARED_STREAM_LENGTH
    try:
        filters.MAX_DECLARED_STREAM_LENGTH=max(prior_limit,expected_size)
        attached=reader.attachments.get(a.companion.name,[])
    finally:
        filters.MAX_DECLARED_STREAM_LENGTH=prior_limit
    identical=len(attached)==1 and attached[0]==a.companion.read_bytes()
    if not identical:bad.append({'reason':'attachment mismatch'})
    for start in range(0,len(pages),4):
        thumbnails=[]
        for j in range(start,min(start+4,len(pages))):
            im=Image.open(a.output/pages[j]['rendered']).convert('RGB')
            im.thumbnail((800,1132));thumbnails.append(im)
        sheet=Image.new('RGB',(1640,2350),'#cbd6df');draw=ImageDraw.Draw(sheet)
        for n,im in enumerate(thumbnails):
            x=10+(n%2)*820;y=35+(n//2)*1170
            draw.text((x,y-22),f'PAGE {start+n+1}',fill='black');sheet.paste(im,(x,y))
        sheet.save(a.output/f'contact-{start+1:03}-{start+len(thumbnails):03}.png')
    result={'status':'PASS' if not bad else 'FAIL','page_count':len(pages),'pages':pages,
      'external_unique_urls':sorted(set(uris)),'internal_links':internal,'issues':bad,
      'owned_companion_bytes':expected_size,'attachment_identical':identical,'pdf_sha256':hashlib.sha256(a.pdf.read_bytes()).hexdigest(),
      'scope':'Automated generation checks; direct visual review recorded separately.'}
    (a.output/'inspection.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'pages':len(pages),'internal_links':len(internal),
      'urls':len(set(uris)),'issues':bad,'attachment_identical':identical}))
    if bad:raise SystemExit(1)

if __name__=='__main__':main()
