These replay commands use the recorded WSL2 shell and Docker Desktop. Extract the companion into a new `source` directory inside an otherwise empty laboratory directory. On Linux, use `docker` in place of `docker.exe`. Paths below are container paths except in the first setup block. Choose fresh build/report/archive destinations; do not run these commands over the supplied evidence.

Fetch reference sources online before starting the offline build job. The fetcher checks archive and individual-file hashes; it never replaces an existing source directory. Its fresh-download path and cached verification were both executed successfully. An attempted download inside the offline container failed as expected; that environment log is preserved, not called a successful fetch.

```sh
# Host shell, in the newly extracted source directory.
python3 -B tools/fetch_sources.py ../upstream
python3 -B tools/fetch_sources.py ../upstream --check-existing
docker.exe build -t psp-guide-lab:locked .
```

Mount the dedicated laboratory directory as `/lab`, with this source at `/lab/source`. The measured job used a network-disabled container, read-only root, all capabilities dropped, no-new-privileges, a 768 MiB memory limit, PID limit 64, and a 256 MiB noexec/nosuid `/tmp` tmpfs. The complete host setup is in REPRODUCE.md; the commands below run inside that container in `/lab/source` as its unprivileged UID 1000. The exact resulting image ID is recorded in the build manifest. Recreating package repositories later may fail if a locked version is no longer retained; do not silently replace a pin.

```sh
# Inside the locked container; fresh paths only.
mkdir /lab/test-tmp
TMPDIR=/lab/test-tmp python -B -m unittest discover -v
make -C /lab/upstream/ebootsigner \
  CFLAGS='-O2 -std=gnu99 -Wall'
sha256sum /lab/upstream/ebootsigner/ebootsign
mkdir -p /lab/build-a/build /lab/build-b/build
cp sample/main.c sample/Makefile /lab/build-a/
cp sample/main.c sample/Makefile /lab/build-b/
make -C /lab/build-a -j2
make -C /lab/build-b -j2
```

The measured legacy signer hash is below. Require it before replaying the pinned signing path. A different host binary hash requires an explained new environment record; it is not permission to bypass the check. The original build completed with two retained legacy C array-parameter warnings. SampleApp itself compiled with -Werror.

```sh
SIGNER_SHA=0474c79ef666947bf16f2695680a380021ccb4be8c78bfca97bb7f871cd2077c
python -B tools/preflight_pbp.py /lab/build-a/EBOOT.PBP \
  --nid-map references/user-nids.json \
  --report /lab/preflight-a.json
python -B tools/nid_audit.py /lab/build-a/SampleApp.prx \
  --nid-map references/user-nids.json \
  --report /lab/imports-a.json
python -B tools/safe_sign.py \
  /lab/build-a/EBOOT.PBP /lab/build-a/EBOOT-signed.PBP \
  --signer /lab/upstream/ebootsigner/ebootsign \
  --signer-sha256 "$SIGNER_SHA" \
  --sources /lab/upstream/ebootsigner \
  --nid-map references/user-nids.json \
  --report /lab/signed-a.json
python -B tools/safe_sign.py \
  /lab/build-b/EBOOT.PBP /lab/build-b/EBOOT-signed.PBP \
  --signer /lab/upstream/ebootsigner/ebootsign \
  --signer-sha256 "$SIGNER_SHA" \
  --sources /lab/upstream/ebootsigner \
  --nid-map references/user-nids.json \
  --report /lab/signed-b.json
```

Run the separate verifier, rather than relying only on the wrapper's report. Its source directory is the fetched signer reference; its cryptography is PyCA, not the C signer's implementation. The NID map describes public SDK mappings, not a stock-firmware export census.

```sh
python -B tools/cross_validate.py \
  /lab/build-a/EBOOT.PBP /lab/build-a/EBOOT-signed.PBP \
  --sources /lab/upstream/ebootsigner \
  --nid-map references/user-nids.json \
  --report /lab/independent-a.json
python -B tools/inspect_sample_elf.py /lab/build-a/SampleApp.elf \
  --report /lab/linked-elf.json
cmp /lab/build-a/SampleApp.elf /lab/build-b/SampleApp.elf
cmp /lab/build-a/SampleApp.prx /lab/build-b/SampleApp.prx
cmp /lab/build-a/PARAM.SFO /lab/build-b/PARAM.SFO
cmp /lab/build-a/EBOOT.PBP /lab/build-b/EBOOT.PBP
cmp /lab/build-a/EBOOT-signed.PBP /lab/build-b/EBOOT-signed.PBP
python -B tools/negative_controls.py \
  --unsigned /lab/build-a/EBOOT.PBP \
  --signed /lab/build-a/EBOOT-signed.PBP \
  --sources /lab/upstream/ebootsigner \
  --nid-map references/user-nids.json \
  --output /lab/negative-controls
```

The supplied artifacts and reports document these operations on the actual example. Raw sizes 4 MiB minus one, exactly 4 MiB, and 4 MiB plus one are preflight padding controls only. Oversized or malformed controls never reach the legacy signer or a device.

Finally, create a new staging tree with README.md, LICENSE.txt, VALIDATION.md, applicable notices, and PSP/GAME/SampleApp/EBOOT.PBP copied from the checked signed output. The supplied installation example is packages/SampleApp-Install.zip. For a fresh replay staging directory:

```sh
python -B tools/package_release.py \
  /lab/stage-install /lab/SampleApp-Install.zip \
  --report /lab/install-package.json
```

This is a new-archive operation. It includes root documentation and every staged payload, then checks CRC, exact members and all payload hashes. Its internal SHA256SUMS excludes itself; the external package inventory hashes that manifest explicitly. The existing output and report paths are refused before packaging can run. Disk failure or a crash is still a separate condition: verify the final artifact hash before installation or distribution.
