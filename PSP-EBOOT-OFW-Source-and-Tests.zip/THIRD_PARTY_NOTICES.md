# Third-party material

The original narrative, new Python laboratory and SampleApp C source use the
MIT license in LICENSE.txt. That grant does not relicense external components.

The example links community PSPSDK and PSPDEV runtime/newlib support. Exact
link inputs and the link map are retained. The installed SDK's PSPSDK,
COPYING.NEWLIB and pthread-embedded notices are copied without alteration into
licenses/. The compiler is GCC15.2.0; runtime support is distributed under its
upstream GCC Runtime Library Exception (https://gcc.gnu.org/onlinedocs/libstdc++/manual/license.html).
These notices cover their respective components, not Sony firmware acceptance.

DejaVu fonts used by the PDF are bundled with their original notice at
document/fonts/LICENSE-DejaVu.txt. Python/Docker/PPSSPP dependencies are
identified and retrieved separately, not bundled as executables/libraries.

Legacy ebootsigner is not bundled as source or a host executable. Its exact
source archives/file fingerprints and retrieval tool are supplied. Upstream
has mixed per-file notices, including a public-domain-marked entrypoint, AFL2
crypto files and All Rights Reserved/unlicensed template material. This project
does not assert blanket redistribution clearance for that legacy collection or
its templates. See research/signing-tools.md and the exact pins. The measured
EBOOT demonstrates that transformation; it carries no Sony-issued publishing
identity or compatibility certification.

No Sony firmware dump or user music is included. References to Sony public
specification pages are citations. The original user PDF is not redistributed.
