"""Independent PyCA AES/CMAC verification for one pinned legacy output format.

Does not reuse the signer's C crypto and does not emulate an OFW loader.
The combined CLI and safe signer additionally require a pinned NID inventory.
"""
import hashlib
import hmac
import re
import struct
from pathlib import Path
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.cmac import CMAC
from .formats import FormatError, need, parse_pbp, parse_prx, validate_unsigned, adjust_relocations

SOURCE_BLOBS = {'main_crypter.h':'49c1db30e4ae5c4c54b1340718972d4e56d56805',
                'internal_keys.h':'905c6c2f8c722c67261f5342ecb4cdd6f85fdaed'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_source(root, filename, expected_blob):
    data=(Path(root)/filename).read_bytes()
    need(len(data)<=1024*1024,'Template source size policy')
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    need(blob==expected_blob,'Pinned source changed: '+filename)
    try:return data.decode('ascii')
    except UnicodeError as exc:raise FormatError('Pinned source encoding') from exc


def c_array(text,name,size):
    match=re.search(r'\b'+re.escape(name)+r'\s*\[[^]]*\]\s*=\s*\{(.*?)\};',text,re.S)
    need(match is not None,'Missing template array: '+name)
    data=bytes(int(x,16) for x in re.findall(r'0x([0-9a-fA-F]{1,2})\b',match[1]))
    need(len(data)==size,'Template array length: '+name)
    return data


def decrypt(key,data):
    need(len(data)%16==0,'AES block alignment')
    context=Cipher(algorithms.AES(key),modes.CBC(bytes(16))).decryptor()
    return context.update(data)+context.finalize()


def cmac(key,data,expected):
    context=CMAC(algorithms.AES(key));context.update(data)
    need(hmac.compare_digest(context.finalize(),expected),'CMAC mismatch')


def verify(unsigned,signed,source_root):
    u,prx,sfo=validate_unsigned(unsigned)
    s=parse_pbp(signed)
    need(all(u.sections[i]==s.sections[i] for i in range(8) if i!=6),'Non-DATA.PSP section changed')
    crypter=read_source(source_root,'main_crypter.h',SOURCE_BLOBS['main_crypter.h'])
    keys=read_source(source_root,'internal_keys.h',SOURCE_BLOBS['internal_keys.h'])
    header=c_array(crypter,'pspHeader',0x150)
    template=c_array(crypter,'kirkHeader',0x110)
    master=c_array(keys,'kirk1_key',16)
    payload=s.sections[6]
    need(len(payload)==0x553450,'Legacy signed DATA.PSP size')
    need(payload[:0x150]==header,'PSP wrapper template mismatch')
    raw=template+payload[0x150:]
    need(struct.unpack_from('<I',raw,0x60)[0]==1 and raw[0x64]==0,'KIRK1 CMAC mode')
    size,offset=struct.unpack_from('<II',raw,0x70)
    need((size,offset)==(0x553300,0x80),'Pinned KIRK layout')
    aligned=(size+15)&~15;end=0x90+offset+aligned
    need(end==len(raw),'KIRK body bounds')
    decoded=decrypt(master,raw[:32]);aes_key,cmac_key=decoded[:16],decoded[16:]
    cmac(cmac_key,raw[0x60:0x90],raw[0x20:0x30])
    cmac(cmac_key,raw[0x60:end],raw[0x30:0x40])
    plain=decrypt(aes_key,raw[0x90+offset:end])
    expected,changed=adjust_relocations(prx)
    need(plain[:len(expected)]==expected,'Decrypted full PRX prefix mismatch')
    transformed=parse_prx(expected)
    need(transformed.module==prx.module and transformed.imports==prx.imports,'Transformation changed module/import metadata')
    return dict(status='PASS',scope='offline crypto + structural SampleApp profile; not firmware acceptance',
                input_sha256=digest(unsigned),signed_sha256=digest(signed),
                raw_prx_bytes=len(prx.data),signed_DATA_PSP_bytes=len(payload),
                relocations_changed=changed,SFO=sfo,module=prx.module,
                file_backed_LOAD_bytes=sum(p['filesz'] for p in prx.segments if p['type']==1),
                static_LOAD_memory_bytes=sum(p['memsz'] for p in prx.segments if p['type']==1),
                source_blobs=SOURCE_BLOBS,crypto_implementation='PyCA cryptography AES-CBC and CMAC',
                import_mapping='REQUIRES_SEPARATE_NID_AUDIT',physical_OFW='NOT TESTED')
