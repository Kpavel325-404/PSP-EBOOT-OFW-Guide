"""POSIX safe-signing procedure for trusted, audited SampleApp build inputs.

Use the documented offline Docker command for OS isolation. This procedure
prevents filename collisions/accidental overwrite; it is not a hostile-code VM.
"""
import hashlib
import os
from pathlib import Path
import stat
import subprocess
import tempfile
from .formats import MAX_CONTAINER,need,validate_unsigned,FormatError
from .nids import load_map,inventory,require_user_profile
from .verify import verify,digest


def read_limited(path,maximum=MAX_CONTAINER):
    path=Path(path)
    need(not path.is_symlink(),'Symlink input is outside this procedure')
    with path.open('rb') as stream:
        before=os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and 0<=before.st_size<=maximum,'Regular input/file size policy')
        data=stream.read(maximum+1);after=os.fstat(stream.fileno())
    need(len(data)==before.st_size and (before.st_size,before.st_mtime_ns,before.st_ctime_ns)==
         (after.st_size,after.st_mtime_ns,after.st_ctime_ns),'Input changed during snapshot')
    return data


def process_limits():
    import resource
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
    resource.setrlimit(resource.RLIMIT_FSIZE,(MAX_CONTAINER,MAX_CONTAINER))
    resource.setrlimit(resource.RLIMIT_CPU,(30,35))
    resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))


def safe_sign(input_path,output_path,signer_path,expected_signer_sha,source_root,nid_map):
    source=Path(input_path);output=Path(output_path)
    need(source.resolve()!=output.resolve(),'Input/output alias is forbidden')
    need(not os.path.lexists(output),'Existing output is never replaced')
    need(output.parent.is_dir() and not output.parent.is_symlink(),'Output parent must be a trusted existing directory')
    original=read_limited(source);container,prx,sfo=validate_unsigned(original)
    imports=inventory(prx,load_map(nid_map));require_user_profile(imports)
    tool=Path(signer_path).resolve();tool_data=read_limited(tool,16*1024*1024)
    need(len(expected_signer_sha)==64 and digest(tool_data)==expected_signer_sha,'Pinned signer hash mismatch')
    need(os.name=='posix','Run signing inside POSIX/WSL/Docker laboratory')
    with tempfile.TemporaryDirectory(prefix='psp-sign-') as folder:
        work=Path(folder);snapshot=work/'input.pbp';candidate=work/'candidate.pbp'
        snapshot.write_bytes(original);snapshot.chmod(0o400)
        try:
            result=subprocess.run([str(tool),'input.pbp','candidate.pbp'],cwd=work,
                                  stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                  timeout=60,check=False,preexec_fn=process_limits)
        except subprocess.TimeoutExpired as exc:
            raise FormatError('Legacy signer host timeout; no output published') from exc
        need(result.returncode==0,'Legacy signer exited '+str(result.returncode)+': '+result.stderr[:4096].decode('utf-8','replace'))
        need(candidate.is_file() and not candidate.is_symlink(),'Missing/unsafe signer output')
        signed=read_limited(candidate)
        checks=verify(original,signed,source_root)
        need(digest(snapshot.read_bytes())==digest(original),'Working input snapshot changed')
        need(digest(read_limited(source))==digest(original),'Original path changed before publication')
        # Exclusive creation is the publication contract. A system crash can
        # leave an incomplete NEW file; verify its recorded hash before use.
        # Existing files, symlinks and hardlinks are never opened for writing.
        created=False
        try:
            with output.open('xb') as stream:
                created=True;stream.write(signed);stream.flush();os.fsync(stream.fileno())
        except Exception:
            if created:output.unlink(missing_ok=True)
            raise
    checks.update(import_audit=imports,import_mapping='VERIFIED (SDK mapping only)',
                  signer_sha256=expected_signer_sha,original_preserved=True,
                  isolated_temporary_job=True,output_no_overwrite=True,
                  signer_stdout=result.stdout[:65536].decode('utf-8','replace'),
                  signer_stderr=result.stderr[:65536].decode('utf-8','replace'))
    return checks
