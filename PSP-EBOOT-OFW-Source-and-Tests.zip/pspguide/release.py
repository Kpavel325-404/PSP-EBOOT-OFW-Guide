"""Fresh ZIP creation with all staging files, root documentation and exact SHA."""
import hashlib
import os
from pathlib import Path,PurePosixPath
import re
import stat
import zipfile
from .formats import need,FormatError


def folder_policy(name):
    need(isinstance(name,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,31}',name) is not None,
         'Lab folder policy:1..32ASCII bytes, letters/digits/underscore/hyphen')
    reserved={'CON','PRN','AUX','NUL'}|{f'{p}{i}' for p in ('COM','LPT') for i in range(1,10)}
    need(name.upper() not in reserved,'Windows reserved folder name')
    return dict(status='PASS',bytes=len(name.encode('ascii')),maximum_bytes=32,
                scope='Laboratory publisher policy, not a verified Sony OFW name limit')


def safe_member(name):
    path=PurePosixPath(name)
    need(name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
         and ':' not in name and all(ord(c)>=32 for c in name),'Unsafe ZIP member name')
    return name


def verify_zip(path):
    with zipfile.ZipFile(path) as archive:
        names=archive.namelist()
        need(len(names)==len(set(names)) and len(names)==len({n.casefold() for n in names}),'Duplicate/case-colliding ZIP members')
        need('SHA256SUMS.txt' in names and archive.testzip() is None,'ZIP CRC/checksum manifest')
        for info in archive.infolist():
            safe_member(info.filename)
            need(not stat.S_ISLNK(info.external_attr>>16),'ZIP symlink member')
        expected={}
        for line in archive.read('SHA256SUMS.txt').decode('utf-8').splitlines():
            pair=line.split('  ',1);need(len(pair)==2,'ZIP SHA256SUMS line')
            sha,name=pair;safe_member(name)
            need(re.fullmatch(r'[0-9a-f]{64}',sha) is not None and name not in expected,'ZIP checksum entry')
            expected[name]=sha
        need(set(names)==set(expected)|{'SHA256SUMS.txt'},'ZIP unexpected/missing members')
        for name,sha in expected.items():
            need(hashlib.sha256(archive.read(name)).hexdigest()==sha,'ZIP SHA mismatch: '+name)
    return dict(status='PASS',CRC='PASS',SHA256='PASS',members=len(names))


def fresh_zip(staging,output,required=('README.md','LICENSE.txt','VALIDATION.md')):
    root=Path(staging);out=Path(output)
    need(root.is_dir() and not root.is_symlink(),'Trusted staging directory required')
    root=root.resolve();target=out.resolve()
    need(target!=root and not target.is_relative_to(root),'ZIP output must be outside staging')
    need(not os.path.lexists(out),'Refusing to update an existing ZIP; choose a fresh filename')
    files={}
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink(),'Staging symlinks are refused')
        if not path.is_file():continue
        name=safe_member(path.relative_to(root).as_posix())
        if name=='SHA256SUMS.txt':continue
        need(name.casefold() not in {x.casefold() for x in files},'Case-colliding staging paths')
        data=path.read_bytes();files[name]=data
        if name.startswith('PSP/GAME/') and len(PurePosixPath(name).parts)>2:
            folder_policy(PurePosixPath(name).parts[2])
    need(all(name in files for name in required),'Required root documentation missing')
    sums=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items()))
    if (root/'SHA256SUMS.txt').exists():
        need((root/'SHA256SUMS.txt').read_text()==sums,'Existing staging SHA256SUMS is stale')
    created=False
    try:
        with out.open('xb') as stream:
            created=True
            with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
                for name,data in [*sorted(files.items()),('SHA256SUMS.txt',sums.encode())]:
                    info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                    info.external_attr=0o100644<<16;archive.writestr(info,data,compresslevel=9)
        result=verify_zip(out)
    except Exception:
        if created:out.unlink(missing_ok=True)
        raise
    result.update(archive_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                  files=[dict(name=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)) for name,data in sorted(files.items())])
    return result
