"""SDK source inventory, explicitly not a database of actual OFW permissions."""
import hashlib
import json
import re
from pathlib import Path
from .formats import need

SDK_REVISION='e2b2b313d4175823a263c2c6cf175311e824eb77'
EXTRA_PUBLIC={'src/display/sceDisplay.S','src/ctrl/sceCtrl.S','src/ge/sceGe_user.S',
              'src/audio/sceAudio.S','src/utility/sceUtility.S','src/net/sceNetInet.S',
              'src/power/scePower.S'}


def public_source(name):
    path=Path(name)
    return ((path.parent.as_posix()=='src/user' or path.as_posix() in EXTRA_PUBLIC)
            and path.suffix=='.S' and '_driver' not in path.name)


def map_sources(sources):
    functions={};files={}
    pattern=re.compile(r'\bIMPORT_FUNC(?:_WITH_ALIAS)?\s+"([A-Za-z0-9_]+)"\s*,\s*0x([0-9A-Fa-f]{8})\s*,\s*([A-Za-z0-9_]+)')
    stub_pattern=re.compile(r'\bSTUB_FUNC(?:_WITH_ALIAS)?\s+0x([0-9A-Fa-f]{8})\s*,\s*([A-Za-z0-9_]+)')
    for filename,data in sorted(sources.items()):
        need(public_source(filename),'Not an explicitly selected public user source: '+filename)
        files[filename]=dict(sha256=hashlib.sha256(data).hexdigest(),
                            git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
        text=data.decode('ascii');stub_library=None
        for line_number,line in enumerate(text.splitlines(),1):
            start=re.search(r'\bSTUB_START\s+"?([A-Za-z0-9_]+)',line)
            if start:stub_library=start[1]
            match=pattern.search(line)
            if match:library,hexnid,symbol=match.groups()
            else:
                match=stub_pattern.search(line)
                if not match:continue
                need(stub_library is not None,'STUB_FUNC without library');library=stub_library
                hexnid,symbol=match.groups()
            key=library+':'+hexnid.upper()
            need(key not in functions or functions[key]['symbol']==symbol,'Conflicting SDK symbol mapping: '+key)
            functions.setdefault(key,dict(symbol=symbol,file=filename,line=line_number))
    return dict(sdk_revision=SDK_REVISION,scope='VERIFIED means exact pinned SDK public-user-stub mapping only',
                functions=functions,source_files=files)


def generate_map(sdk_root):
    root=Path(sdk_root)
    paths=sorted((root/'src/user').glob('*.S'))+[root/name for name in sorted(EXTRA_PUBLIC)]
    return map_sources({path.relative_to(root).as_posix():path.read_bytes() for path in paths})


def load_map(path):
    data=json.loads(Path(path).read_text())
    need(data.get('sdk_revision')==SDK_REVISION and isinstance(data.get('functions'),dict),'NID reference profile/revision')
    need(all(public_source(path) for path in data.get('source_files',{})),'NID map source provenance')
    return data


def inventory(prx,mapping):
    need(mapping.get('sdk_revision')==SDK_REVISION,'NID mapping revision')
    attribute=prx.module['attribute']
    module_status='VERIFIED' if attribute==0 else ('UNSUPPORTED' if attribute&0x1000 else 'UNKNOWN')
    rows=[]
    for library in prx.imports:
        for nid in library['nids']:
            key=library['library']+':'+f'{nid:08X}';entry=mapping['functions'].get(key)
            row=dict(library=library['library'],nid=f'0x{nid:08X}',version=f'0x{library["version"]:04X}',
                     import_attributes=f'0x{library["attributes"]:04X}',status='VERIFIED' if entry else 'UNKNOWN',
                     symbol=entry['symbol'] if entry else None,
                     evidence='Pinned SDK public-user-stub mapping only' if entry else 'No match in selected reference sources')
            if entry:row['source']=dict(entry,revision=SDK_REVISION)
            rows.append(row)
    return dict(module=prx.module,module_status=module_status,
                module_policy='Only inner attribute0x0000 accepted by this user-profile laboratory',
                functions=rows,library_count=len(prx.imports),function_count=len(rows),
                SDK_mapping_revision=SDK_REVISION,firmware_exports='UNKNOWN',
                firmware_import_attribute_acceptance='UNKNOWN',physical_OFW='NOT TESTED',
                status='VERIFIED' if module_status=='VERIFIED' and all(r['status']=='VERIFIED' for r in rows) else ('UNSUPPORTED' if module_status=='UNSUPPORTED' else 'UNKNOWN'))


def require_user_profile(report):
    need(report['module_status']=='VERIFIED','Unsupported or UNKNOWN inner user module attribute')
    need(all(row['status']=='VERIFIED' for row in report['functions']),'UNKNOWN import mapping; stop for manual investigation')
