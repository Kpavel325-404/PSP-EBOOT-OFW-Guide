"""Bounded, deliberately narrow parser for the laboratory's PSP user PRX profile.

These are explicit application-profile limits, not universal PSP format limits.
No pointer in the input is dereferenced outside validated file-backed LOAD ranges.
"""
from dataclasses import dataclass
import struct

MAX_CONTAINER = 64 * 1024 * 1024
MAX_RAW_PRX = 4 * 1024 * 1024
MAX_STATIC_MEMORY = 32 * 1024 * 1024


class FormatError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise FormatError(message)


def span(offset, size, limit, what):
    need(0 <= offset <= limit and 0 <= size <= limit-offset, what+' bounds')
    return offset, offset+size


def cstring(data, start, limit, what, encoding='ascii'):
    span(start, 1, len(data), what)
    end = data.find(b'\0', start, min(len(data), limit))
    need(end >= start, what+' terminator')
    try:
        return data[start:end].decode(encoding)
    except UnicodeError as exc:
        raise FormatError(what+' encoding') from exc


@dataclass
class Pbp:
    data: bytes
    offsets: tuple
    sections: list


def parse_pbp(data):
    data = bytes(data)
    need(40 <= len(data) <= MAX_CONTAINER, 'PBP size policy')
    magic, version, *offsets = struct.unpack_from('<2I8I', data)
    need(magic == 0x50425000 and version == 0x10000, 'PBP magic/version')
    ends = (*offsets, len(data))
    need(offsets[0] == 40 and all(a <= b <= len(data) for a,b in zip(ends,ends[1:])), 'PBP section')
    return Pbp(data, tuple(offsets), [data[a:b] for a,b in zip(ends,ends[1:])])


def parse_sfo(data):
    need(20 <= len(data) <= 1024*1024, 'SFO size policy')
    magic, version, key_at, data_at, count = struct.unpack_from('<5I', data)
    need(magic == 0x46535000 and version == 0x101, 'SFO magic/version')
    need(count <= 256, 'SFO entry count policy')
    _, table_end = span(20, count*16, len(data), 'SFO entry table')
    need(table_end <= key_at <= data_at <= len(data) and data_at%4 == 0, 'SFO table ordering/alignment')
    result = {}; occupied = []
    for i in range(count):
        key, fmt, length, maximum, relative = struct.unpack_from('<HHIII',data,20+16*i)
        need(key_at+key < data_at, 'SFO key offset')
        name = cstring(data,key_at+key,data_at,'SFO key')
        need(name and len(name) <= 127 and name not in result, 'SFO duplicate/empty key')
        need(length <= maximum and maximum > 0 and relative%4 == 0, 'SFO value length/alignment')
        begin,end = span(data_at+relative,maximum,len(data),'SFO value')
        need(all(end <= a or begin >= b for a,b in occupied), 'SFO overlapping values')
        occupied.append((begin,end)); raw=data[begin:begin+length]
        if fmt == 0x0404:
            need(length == 4, 'SFO integer width'); value=struct.unpack('<I',raw)[0]
        elif fmt == 0x0204:
            need(length > 0 and raw[-1:] == b'\0' and b'\0' not in raw[:-1], 'SFO string terminator')
            try:value=raw[:-1].decode('utf-8')
            except UnicodeError as exc:raise FormatError('SFO string encoding') from exc
        elif fmt == 0x0004:
            value=raw.hex()
        else:
            raise FormatError('SFO unsupported data type')
        result[name]=value
    return result


def check_sample_sfo(values):
    expected={'TITLE':'SampleApp','CATEGORY':'MG','BOOTABLE':1,'MEMSIZE':0,'PSP_SYSTEM_VER':'6.60'}
    for key,value in expected.items():
        need(type(values.get(key)) is type(value) and values.get(key)==value, 'SampleApp SFO '+key)


@dataclass
class Prx:
    data: bytes
    sections: list
    segments: list
    module: dict
    imports: list
    relocations: list
    entry: int

    def address(self, address, size):
        matches=[]
        for segment in self.segments:
            if segment['type']==1 and segment['vaddr'] <= address and size <= segment['filesz']-(address-segment['vaddr']):
                offset=segment['offset']+address-segment['vaddr']
                matches.append(span(offset,size,len(self.data),'mapped address')[0])
        need(len(matches)==1, 'Unmapped/ambiguous file-backed address')
        return matches[0]

    def address_string(self,address,what):
        offset=self.address(address,1)
        # Validate each byte against the file-backed mapping, not the whole file.
        raw=bytearray()
        for n in range(128):
            at=self.address(address+n,1);byte=self.data[at]
            if not byte:
                try:return raw.decode('ascii')
                except UnicodeError as exc:raise FormatError(what+' encoding') from exc
            raw.append(byte)
        raise FormatError(what+' length/terminator')


def parse_prx(data):
    data=bytes(data)
    need(52 <= len(data) <= MAX_RAW_PRX,'Raw PRX size / legacy4MiB input policy')
    h=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
    ident,kind,machine,version,entry,phoff,shoff,flags,ehsize,phsize,phnum,shsize,shnum,shstrings=h
    need(ident[:7]==b'\x7fELF\x01\x01\x01' and (kind,machine,version)==(0xffa0,8,1),'ELF32/MIPS/PRX identity')
    need(ehsize==52 and phsize==32 and shsize==40,'ELF table entry sizes')
    need(0 < phnum <= 128 and 0 < shnum <= 4096 and 0 <= shstrings < shnum,'ELF table count policy')
    need(phoff>=52 and shoff>=52,'ELF table offsets')
    _,phend=span(phoff,phsize*phnum,len(data),'ELF program table')
    _,shend=span(shoff,shsize*shnum,len(data),'ELF section table')
    need(phend<=shoff or shend<=phoff,'ELF overlapping header tables')
    segments=[];memory=0
    for i in range(phnum):
        typ,offset,va,pa,filesz,memsz,pflags,align=struct.unpack_from('<8I',data,phoff+i*32)
        span(offset,filesz,len(data),'ELF program data')
        need(memsz>=filesz and va+memsz<=0x100000000,'ELF segment memory range')
        need(align in (0,1) or (align&(align-1))==0,'ELF segment alignment')
        if typ==1:
            memory+=memsz
            need(memory<=MAX_STATIC_MEMORY,'Static memory policy')
            need(all(va+memsz<=p['vaddr'] or va>=p['vaddr']+p['memsz'] for p in segments if p['type']==1),'ELF overlapping LOAD memory')
        segments.append(dict(type=typ,offset=offset,vaddr=va,filesz=filesz,memsz=memsz,flags=pflags,align=align))
    need(any(p['type']==1 and p['flags']&1 and p['vaddr']<=entry<p['vaddr']+p['filesz'] for p in segments),'ELF entry in executable file-backed LOAD')
    raw_sections=[struct.unpack_from('<10I',data,shoff+i*40) for i in range(shnum)]
    string_row=raw_sections[shstrings]
    need(string_row[1]==3,'ELF section-name string table')
    name_start,name_end=span(string_row[4],string_row[5],len(data),'ELF section names')
    sections=[]
    for row in raw_sections:
        name,typ,sflags,addr,offset,size,link,info,align,entsize=row
        need(name<string_row[5],'ELF section-name offset')
        label=cstring(data,name_start+name,name_end,'ELF section name')
        if typ!=8:span(offset,size,len(data),'ELF section data')
        need(addr+size<=0x100000000,'ELF section address overflow')
        need(align in (0,1) or (align&(align-1))==0,'ELF section alignment')
        need(link<shnum,'ELF section link')
        sections.append(dict(name=label,type=typ,flags=sflags,address=addr,offset=offset,size=size,link=link,info=info,alignment=align,entry_size=entsize))
    module_sections=[s for s in sections if s['name']=='.rodata.sceModuleInfo']
    need(len(module_sections)==1 and module_sections[0]['size']>=52 and module_sections[0]['type']!=8,'Module info section')
    at=module_sections[0]['offset']
    attr,minor,major,name,gp,enttop,entend,stubtop,stubend=struct.unpack_from('<HBB28s5I',data,at)
    need(b'\0' in name,'Module name terminator')
    try:module_name=name.split(b'\0',1)[0].decode('ascii')
    except UnicodeError as exc:raise FormatError('Module name encoding') from exc
    need(module_name and entend>=enttop and stubend>=stubtop,'Module ranges/name')
    module=dict(name=module_name,attribute=attr,version=f'{major}.{minor}',gp=gp,exports_start=enttop,exports_end=entend,imports_start=stubtop,imports_end=stubend)
    prx=Prx(data,sections,segments,module,[],[],entry)
    need(prx.address(module_sections[0]['address'],52)==at,'Module info mapping')
    if entend>enttop:prx.address(enttop,entend-enttop)
    if stubend>stubtop:prx.address(stubtop,stubend-stubtop)
    cursor=stubtop
    while cursor<stubend:
        pos=prx.address(cursor,20)
        nameptr,libver,attributes,words,variables,functions,nidptr,stubptr=struct.unpack_from('<IHHBBHII',data,pos)
        need(words==5 and variables==0,'Unsupported import descriptor/variable imports in narrow profile')
        need(cursor+words*4<=stubend and functions<=4096,'Import descriptor/function range')
        library=prx.address_string(nameptr,'Import library')
        need(library and all(32<=ord(c)<127 for c in library),'Import library name')
        nids_at=prx.address(nidptr,functions*4) if functions else 0
        code_at=prx.address(stubptr,functions*8) if functions else 0
        nids=list(struct.unpack_from('<'+'I'*functions,data,nids_at)) if functions else []
        prx.imports.append(dict(library=library,version=libver,attributes=attributes,descriptor_words=words,variable_count=variables,function_count=functions,nids=nids,nid_address=nidptr,stub_address=stubptr,descriptor_address=cursor))
        cursor+=words*4
    need(cursor==stubend,'Import table end')
    loads=[p for p in segments if p['type']==1]
    # Legacy C mutates relocation records while rereading ELF metadata. The
    # record storage must therefore be disjoint from every header, mapped LOAD
    # byte and other section: otherwise a validated table can change mid-loop.
    protected=[(0,52),(phoff,phend),(shoff,shend)]
    protected += [(p['offset'],p['offset']+p['filesz']) for p in loads if p['filesz']]
    protected += [(s['offset'],s['offset']+s['size']) for s in sections
                  if s['type'] not in (8,0x700000a0) and s['size']]
    relocation_spans=[]
    for section in sections:
        if section['type']!=0x700000a0:continue
        begin=section['offset'];end=begin+section['size']
        need(not section['size'] or all(end<=a or begin>=b
             for a,b in protected+relocation_spans),'Relocation storage overlap')
        if section['size']:relocation_spans.append((begin,end))
        need(section['size']%8==0,'Relocation record alignment')
        for pos in range(section['offset'],section['offset']+section['size'],8):
            offset,info=struct.unpack_from('<II',data,pos);typ=info&255
            target=(info>>8)&255;base=(info>>16)&255
            need(typ in range(11) and not info&0xff000000,'Unrecognized relocation encoding')
            need(target<len(loads) and base<len(loads),'Relocation LOAD index')
            need(offset%4==0 and offset+4<=loads[target]['filesz'],'Relocation target bounds/alignment')
            prx.relocations.append(dict(file_offset=pos,offset=offset,info=info,type=typ,target_segment=target,base_segment=base))
    return prx


def adjust_relocations(prx):
    changed=0;data=bytearray(prx.data)
    for row in prx.relocations:
        if row['type']==7:
            struct.pack_into('<I',data,row['file_offset']+4,row['info']&0xffffff00);changed+=1
    return bytes(data),changed


def validate_unsigned(data):
    container=parse_pbp(data);values=parse_sfo(container.sections[0]);check_sample_sfo(values)
    prx=parse_prx(container.sections[6])
    need(prx.module['attribute']==0,'SampleApp user module attribute must be0x0000')
    need(prx.module['name']=='SampleApp','SampleApp inner module name')
    return container,prx,values
