/* SPDX-License-Identifier: MIT */
#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <pspge.h>

PSP_MODULE_INFO("SampleApp", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);
PSP_MAIN_THREAD_STACK_SIZE_KB(32);
PSP_HEAP_SIZE_KB(2048);

volatile unsigned sample_ready, sample_heartbeat, sample_exit_reason;
volatile unsigned sample_free_total, sample_free_max, sample_ge_bytes;
static int quit;

static int exit_callback(int arg1, int arg2, void *common)
{
    (void)arg1; (void)arg2; (void)common;
    sample_exit_reason = 1;
    __atomic_store_n(&quit, 1, __ATOMIC_RELAXED);
    return 0;
}

int main(void)
{
    SceUID cb = sceKernelCreateCallback("SampleExit", exit_callback, NULL);
    if (cb < 0 || sceKernelRegisterExitCallback(cb) < 0) {
        sceKernelExitGame();
        return 1;
    }
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);
    pspDebugScreenInit();
    pspDebugScreenPrintf("SampleApp - User Mode\n");
    pspDebugScreenPrintf("Physical stock OFW: NOT TESTED\n");
    pspDebugScreenPrintf("CROSS: application exit\nHOME: exit callback\n");
    sample_free_total = sceKernelTotalFreeMemSize();
    sample_free_max = sceKernelMaxFreeMemSize();
    sample_ge_bytes = sceGeEdramGetSize();
    sample_ready = 1;
    while (!__atomic_load_n(&quit, __ATOMIC_RELAXED)) {
        SceCtrlData pad = {0};
        if (sceCtrlPeekBufferPositive(&pad, 1) > 0 && (pad.Buttons & PSP_CTRL_CROSS)) {
            sample_exit_reason = 2;
            __atomic_store_n(&quit, 1, __ATOMIC_RELAXED);
        }
        ++sample_heartbeat;
        sceKernelDelayThreadCB(20000);
    }
    sceKernelExitGame();
    return 0;
}
