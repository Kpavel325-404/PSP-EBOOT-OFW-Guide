# Reproduce the SampleApp laboratory

Use a new directory named `source` inside an empty dedicated laboratory root.
The companion's `artifacts/build-a` and `artifacts/build-b` are preserved outputs,
not working build directories. Do not delete them to replay the lab.

Prerequisites: Linux or Windows 11/WSL2 with Docker Desktop, Python3, network
access for the pinned source/image/dependency acquisition, and sufficient local
space. The actual SDK/compiler/signing work ran in the locked Docker image.
`document/lab-commands.md` contains the complete commands and their scopes.
All of its SDK, signing, comparison, negative-control and packaging operations
were executed; paths in the replay are normalized to fresh destinations.

## Host setup

Fetch sources from the host (online), not from the network-disabled job:

```sh
python3 -B tools/fetch_sources.py ../upstream
python3 -B tools/fetch_sources.py ../upstream --check-existing
docker.exe build -t psp-guide-lab:locked .
```

From WSL2, set the bind source to the Windows spelling of your own laboratory
root. This example resolves the actual current parent directory; it does not
contain a user-specific hard-coded path. With Linux Docker use `docker` and
`LAB_BIND=$(cd .. && pwd)` instead.

```sh
LAB_BIND=$(wslpath -w "$(cd .. && pwd)")
docker.exe run -d --name psp-guide-replay \
  --network none --read-only --cap-drop ALL \
  --security-opt no-new-privileges --pids-limit 64 --memory 768m \
  --tmpfs /tmp:rw,noexec,nosuid,size=256m \
  --mount "type=bind,source=$LAB_BIND,target=/lab" \
  --workdir /lab/source --entrypoint /bin/sh \
  psp-guide-lab:locked -c 'sleep infinity'
docker.exe exec -it --user 1000:1000 psp-guide-replay /bin/sh
```

Ensure this owned laboratory bind permits writes by UID1000. The noexec /tmp
is intentional: test executable fixtures use the owned `/lab/test-tmp` via
TMPDIR. The production signer executable is outside /tmp and receives only
scratch input/output paths. Do not mount unrelated projects, firmware or cards.
The source is not a hostile-code sandbox; trusted build tools and parent
folders are assumed. Container controls are complementary limits.

The measured base image digest, derived image ID,93 APK pins,4 Python pins,
compiler/tool/library hashes and source/build comparisons are in
`environment/build-manifest.json`, `environment/apk-lock.txt`, Dockerfile and
requirements-lab.txt. Package version locks are not immutable package mirrors.
Two builds in this exact environment matched; other hosts/environments remain
unproven. Installed SDK source commit is UNKNOWN, even though installed
build.mak bytes match the pinned reference copy.

## Runtime and document tooling

Runtime evidence used the official PPSSPP1.20.4 AppImage with its exact hash in
`evidence/runtime/attempt-005/report.json`, in an owned Python3.14/Mesa/Xvfb
container. The reusable CLI is `python tools/runtime_sample.py --help`.
Dependencies were websockets17.3, pyelftools0.33, Pillow13.0.0. Runtime base,
image ID and install logs are in evidence/runtime/environment.json. The
`--emulator`, `--appimage`, `--eboot`, `--elf`, `--prx`, `--source`, `--output`
arguments identify your local files. It creates fresh evidence only; launch
routes are emulator direct paths, not physical XMB. The emulator is not bundled.

The PDF builder uses requirements-document.txt and the bundled open DejaVu
fonts. Use Python3.12 with those pinned packages, then:

```sh
python -B document/build_pdf.py \
  --companion PSP-EBOOT-OFW-Source-and-Tests.zip \
  --output PSP-EBOOT-OFW-Building-and-Paranoid-Cross-Validation.pdf \
  --work rendered/replay
```

The output PDF destination must not exist. The ZIP is frozen first and attached
byte-for-byte. PDF generation never rebuilds SampleApp. Every-page rendered QA
and attachment/hash checks are separate production checks, not assumptions
made by the builder.

## Interpretation

The original32-test PASS, later38-test final PASS,13 real negative CLI controls,
A/B hashes and six PPSSPP observations are retained. Earlier FAIL/ERROR logs are
retained with explanations. Physical PSP stock OFW, physical HOME/XMB and
suspend/resume remain NOT TESTED; physical performance/peak memory NOT MEASURED.

Exact PPSSPP acquisition, extraction, owned runtime-container setup and complete
six-case command are provided in `evidence/runtime/REPLAY.md`. Its reconstructed
setup recipe is distinguished from the preserved measured run.

## Concrete installation staging

Inside the fresh SDK laboratory after successful verification, create the
staging directory (it must be new), copy only checked bytes and root docs, then
package outside that directory:

```sh
mkdir -p /lab/stage-install/PSP/GAME/SampleApp
cp /lab/build-a/EBOOT-signed.PBP \
  /lab/stage-install/PSP/GAME/SampleApp/EBOOT.PBP
cp README.md LICENSE.txt VALIDATION.md THIRD_PARTY_NOTICES.md \
  /lab/stage-install/
cp -r licenses /lab/stage-install/licenses
python -B tools/package_release.py \
  /lab/stage-install /lab/SampleApp-Install.zip \
  --report /lab/install-package.json
```

The supplied installation ZIP uses a shorter installation-focused README rather
than the companion's source-directory tour. Both define the same binary and
layout; the full archived text is inspectable in packages/SampleApp-Install.zip.

The complete companion is about75MB because it retains both builds and the
byte-identical per-case runtime input copies. `document/inspect_pdf.py` compares
the attachment byte-for-byte. It raises pypdf's75,000,000-byte declared-stream
policy only to the exact known companion size, with a separate128MiB ceiling,
then restores the setting. It does not disable resource limits or modify the
installed library. The first final attachment check exposed this library-policy
limit; that failed log is preserved in the delivery checkpoint.
