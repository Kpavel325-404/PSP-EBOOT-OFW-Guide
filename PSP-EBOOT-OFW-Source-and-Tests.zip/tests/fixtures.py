"""Synthetic parser fixtures, never presented as runnable PSP programs."""
import struct


def sfo(values=None):
    values = values or {'TITLE': 'SampleApp', 'CATEGORY': 'MG', 'BOOTABLE': 1,
                        'MEMSIZE': 0, 'PSP_SYSTEM_VER': '6.60'}
    keys = bytearray(); data = bytearray(); entries = []
    for key, value in sorted(values.items()):
        key_at = len(keys); keys.extend(key.encode('ascii')+b'\0')
        while len(data) % 4: data.append(0)
        if isinstance(value, int): raw = struct.pack('<I', value); fmt = 0x0404
        else: raw = value.encode('utf-8')+b'\0'; fmt = 0x0204
        entries.append(struct.pack('<HHIII', key_at, fmt, len(raw), len(raw), len(data)))
        data.extend(raw)
    start = 20+16*len(entries); data_at = (start+len(keys)+3)&~3
    return (struct.pack('<5I', 0x46535000, 0x101, start, data_at, len(entries))
            +b''.join(entries)+keys+b'\0'*(data_at-start-len(keys))+data)


def prx(attribute=0, nid=0x984C27E7, relocation=7):
    blob = bytearray(0x200)
    blob[0x100:0x110] = struct.pack('<4I', 0x03e00008, 0, 0, 0)
    blob[0x120:0x154] = struct.pack('<HBB28s5I', attribute, 0, 1, b'SampleApp',
                                    0, 0, 0, 0xa0, 0xb4)
    blob[0x160:0x16b] = b'sceDisplay\0'
    struct.pack_into('<I', blob, 0x180, nid)
    struct.pack_into('<2I', blob, 0x190, 0x03e00008, 0)
    struct.pack_into('<IHHBBHII', blob, 0x1a0, 0x60, 0, 0x4001, 5, 0, 1, 0x80, 0x90)
    names = ['','.text','.rodata.sceModuleInfo','.rodata.sceResident',
             '.rodata.sceNid','.sceStub.text','.lib.stub','.bss','.shstrtab','.rel.text']
    strings = b''; name_offsets = []
    for name in names: name_offsets.append(len(strings)); strings += name.encode()+b'\0'
    strings_at = len(blob); blob.extend(strings)
    while len(blob) % 4: blob.append(0)
    rel_at = len(blob); blob.extend(struct.pack('<II', 0, relocation))
    table = len(blob)
    rows = [(0,0,0,0,0,0,0,0,0), (1,6,0,0x100,16,0,0,4,0),
            (1,2,0x20,0x120,52,0,0,4,0), (1,2,0x60,0x160,11,0,0,4,0),
            (1,2,0x80,0x180,4,0,0,4,0), (1,6,0x90,0x190,8,0,0,4,0),
            (1,2,0xa0,0x1a0,20,0,0,4,0), (8,3,0xc0,0x1c0,32,0,0,4,0),
            (3,0,0,strings_at,len(strings),0,0,1,0),
            (0x700000a0,0,0,rel_at,8,0,1,4,8)]
    for name_at, row in zip(name_offsets, rows): blob.extend(struct.pack('<10I', name_at, *row))
    struct.pack_into('<16sHHIIIIIHHHHHH', blob, 0,
                     b'\x7fELF\x01\x01\x01'+b'\0'*9,0xffa0,8,1,0,52,table,0,52,32,1,40,len(rows),8)
    struct.pack_into('<8I', blob, 52, 1,0x100,0,0,0xc0,0xe0,7,0x100)
    return bytes(blob)


def pbp(payload=None, metadata=None):
    sections = [sfo() if metadata is None else metadata,b'',b'',b'',b'',b'',
                prx() if payload is None else payload,b'']
    offsets = []; at = 40
    for section in sections: offsets.append(at); at += len(section)
    return struct.pack('<2I8I',0x50425000,0x10000,*offsets)+b''.join(sections)
