import importlib
import tempfile
import unittest
from pathlib import Path
from tests.fixtures import pbp,prx,sfo
from pspguide.formats import FormatError

try:v=importlib.import_module('pspguide.verify')
except ModuleNotFoundError:v=None


class VerificationTests(unittest.TestCase):
    def setUp(self):self.assertIsNotNone(v,'independent verifier implementation missing')

    def test_matching_wrong_sfo_is_not_a_profile_pass(self):
        b=pbp(metadata=sfo({'TITLE':'SampleApp','CATEGORY':'MG','BOOTABLE':1,'MEMSIZE':1,'PSP_SYSTEM_VER':'6.60'}))
        with self.assertRaisesRegex(FormatError,'MEMSIZE'):v.verify(b,b,Path('not-needed'))

    def test_kernel_inner_module_is_not_accepted_by_wrapper_checks(self):
        b=pbp(payload=prx(attribute=0x1000))
        with self.assertRaisesRegex(FormatError,'user module'):v.verify(b,b,Path('not-needed'))

    def test_pinned_source_blob_change_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.h';p.write_bytes(b'abc')
            # Git blob SHA1 of the three bytes, not a raw-file SHA1.
            self.assertEqual(v.read_source(Path(d),'x.h','f2ba8f84ab5c1bce84a7b441cb1959cfc7093b7f'),'abc')
            p.write_bytes(b'abd')
            with self.assertRaisesRegex(FormatError,'Pinned source'):v.read_source(Path(d),'x.h','f2ba8f84ab5c1bce84a7b441cb1959cfc7093b7f')

    def test_template_array_missing_or_wrong_width_rejected(self):
        for text in ['', 'unsigned char x[2]={0x12};']:
            with self.assertRaises(FormatError):v.c_array(text,'x',2)


if __name__=='__main__':unittest.main()
