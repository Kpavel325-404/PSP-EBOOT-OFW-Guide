"""Regressions for independent review findings; no legacy binary invoked."""
import contextlib
import io
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from tests.fixtures import prx
from pspguide.formats import parse_prx, FormatError
from tools._cli import run


class CliReportSafetyTests(unittest.TestCase):
    def test_existing_report_prevents_operation_and_preserves_report(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);report=root/'report.json';report.write_text('preserved\n')
            output=root/'artifact'
            def operation():
                output.write_bytes(b'published');return {'status':'PASS'}
            with contextlib.redirect_stdout(io.StringIO()):
                code=run(operation,SimpleNamespace(report=report))
            self.assertEqual(code,1)
            self.assertFalse(output.exists(),'Operation must not run if report cannot be reserved')
            self.assertEqual(report.read_text(),'preserved\n')

    def test_missing_report_parent_prevents_operation(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);output=root/'artifact'
            def operation():
                output.write_bytes(b'published');return {'status':'PASS'}
            with contextlib.redirect_stdout(io.StringIO()):
                code=run(operation,SimpleNamespace(report=root/'absent/report.json'))
            self.assertEqual(code,1);self.assertFalse(output.exists())

    def test_report_output_alias_is_refused_before_work(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'artifact'
            calls=[]
            def operation():
                calls.append(True);return {'status':'PASS'}
            with contextlib.redirect_stdout(io.StringIO()):
                code=run(operation,SimpleNamespace(report=target,output=target))
            self.assertEqual(code,1);self.assertEqual(calls,[])
            self.assertFalse(target.exists())

    def test_reserved_report_records_success_and_operation_failure(self):
        import json
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for label,fail in [('success',False),('failure',True)]:
                report=root/(label+'.json')
                def operation():
                    if fail:raise ValueError('controlled refusal')
                    return {'status':'PASS','value':3}
                with contextlib.redirect_stdout(io.StringIO()):
                    code=run(operation,SimpleNamespace(report=report))
                self.assertEqual(code,1 if fail else 0)
                result=json.loads(report.read_text())
                self.assertEqual(result['status'],'FAIL' if fail else 'PASS')


class RelocationStorageSafetyTests(unittest.TestCase):
    def test_relocation_cannot_rewrite_section_table_pointer(self):
        # The old parser accepted this. At file offset28, e_phoff=52 is a
        # valid relocation target offset and e_shoff=0x10007 encodes type7,
        # target LOAD0, base LOAD1. The legacy mutation would clear the low
        # byte of e_shoff while its C loop is still reading section headers.
        blob=bytearray(prx());old_table=struct.unpack_from('<I',blob,32)[0]
        section_table=bytes(blob[old_table:old_table+400]);new_table=0x10007
        blob.extend(bytes(new_table+400-len(blob)))
        blob[new_table:new_table+400]=section_table
        struct.pack_into('<I',blob,32,new_table)
        struct.pack_into('<H',blob,44,2)
        struct.pack_into('<8I',blob,84,1,0x1000,0x10000,0,64,64,6,1)
        struct.pack_into('<I',blob,new_table+9*40+16,28)
        with self.assertRaisesRegex(FormatError,'Relocation storage overlap'):
            parse_prx(blob)

    def test_duplicate_relocation_storage_is_refused(self):
        blob=bytearray(prx());table=struct.unpack_from('<I',blob,32)[0]
        # Re-purpose the empty null section as a second identical relocation
        # section. Both records are otherwise valid and file-bounded.
        blob[table:table+40]=blob[table+9*40:table+10*40]
        with self.assertRaisesRegex(FormatError,'Relocation storage overlap'):
            parse_prx(blob)


if __name__=='__main__':unittest.main()
