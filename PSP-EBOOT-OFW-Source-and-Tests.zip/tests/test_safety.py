import hashlib
import importlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from tests.fixtures import pbp,prx
from pspguide.formats import FormatError
from pspguide.nids import map_sources

try:s=importlib.import_module('pspguide.sign')
except ModuleNotFoundError:s=None
try:r=importlib.import_module('pspguide.release')
except ModuleNotFoundError:r=None


class SigningSafetyTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(s,'safe signer implementation missing')
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.input=self.root/'input.pbp';self.input.write_bytes(pbp())
        self.tool=self.root/'failure-tool';self.tool.write_text('#!/bin/sh\necho controlled-failure >&2\nexit 17\n');self.tool.chmod(0o755)
        self.map=self.root/'map.json';self.map.write_text(json.dumps(map_sources({'src/display/sceDisplay.S':b'IMPORT_FUNC "sceDisplay",0x984C27E7,sceDisplayWaitVblankStart\n'})))
        self.tool_sha=hashlib.sha256(self.tool.read_bytes()).hexdigest()

    def run_sign(self,output,**kw):
        return s.safe_sign(self.input,output,self.tool,self.tool_sha,self.root,self.map,**kw)

    def test_identical_input_output_refused_without_mutation(self):
        before=self.input.read_bytes()
        with self.assertRaises(FormatError):self.run_sign(self.input)
        self.assertEqual(self.input.read_bytes(),before)

    def test_existing_output_refused_and_preserved(self):
        out=self.root/'output.pbp';out.write_bytes(b'known-good')
        with self.assertRaises(FormatError):self.run_sign(out)
        self.assertEqual(out.read_bytes(),b'known-good')

    def test_hardlink_and_symlink_aliases_refused(self):
        before=self.input.read_bytes()
        for mode in ['hard','symbolic']:
            out=self.root/mode
            (os.link if mode=='hard' else os.symlink)(self.input,out)
            with self.subTest(mode=mode),self.assertRaises(FormatError):self.run_sign(out)
            self.assertEqual(self.input.read_bytes(),before)

    def test_bad_tool_hash_refused(self):
        with self.assertRaisesRegex(FormatError,'signer hash'):
            s.safe_sign(self.input,self.root/'out',self.tool,'0'*64,self.root,self.map)

    def test_oversized_raw_input_never_passed_to_legacy(self):
        self.input.write_bytes(pbp(payload=b'X'*(4*1024*1024+1)))
        with self.assertRaisesRegex(FormatError,'4MiB'):self.run_sign(self.root/'out')
        self.assertFalse((self.root/'out').exists())

    def test_unknown_import_refused_before_signer_execution(self):
        self.input.write_bytes(pbp(payload=prx(nid=0xdeadbeef)))
        with self.assertRaisesRegex(FormatError,'UNKNOWN'):self.run_sign(self.root/'out')

    def test_failed_signer_leaves_original_and_output_untouched(self):
        before=self.input.read_bytes()
        with self.assertRaisesRegex(FormatError,'17'):self.run_sign(self.root/'out')
        self.assertEqual(self.input.read_bytes(),before);self.assertFalse((self.root/'out').exists())


class ReleaseSafetyTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(r,'fresh release packager implementation missing')
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.stage=self.root/'stage';self.stage.mkdir()
        for name in ['README.md','LICENSE.txt','VALIDATION.md']:(self.stage/name).write_text(name+'\n')
        app=self.stage/'PSP/GAME/SampleApp';app.mkdir(parents=True);(app/'EBOOT.PBP').write_bytes(b'owned fixture')

    def test_root_docs_and_every_checksum_in_new_archive(self):
        import zipfile
        out=self.root/'candidate.zip';r.fresh_zip(self.stage,out)
        with zipfile.ZipFile(out) as z:
            for name in ['README.md','LICENSE.txt','VALIDATION.md','SHA256SUMS.txt','PSP/GAME/SampleApp/EBOOT.PBP']:
                self.assertIn(name,z.namelist())
            for line in z.read('SHA256SUMS.txt').decode().splitlines():
                sha,name=line.split('  ',1);self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),sha)

    def test_existing_zip_is_refused_instead_of_retaining_stale_members(self):
        import zipfile
        out=self.root/'candidate.zip'
        with zipfile.ZipFile(out,'w') as z:z.writestr('obsolete.txt','old')
        before=out.read_bytes()
        with self.assertRaises(FormatError):r.fresh_zip(self.stage,out)
        self.assertEqual(out.read_bytes(),before)

    def test_missing_docs_and_symlinks_refused(self):
        (self.stage/'README.md').unlink()
        with self.assertRaises(FormatError):r.fresh_zip(self.stage,self.root/'out1.zip')
        (self.stage/'README.md').write_text('readme');os.symlink(self.root/'outside',self.stage/'link')
        with self.assertRaises(FormatError):r.fresh_zip(self.stage,self.root/'out2.zip')

    def test_archive_inside_its_own_staging_is_refused(self):
        with self.assertRaises(FormatError):r.fresh_zip(self.stage,self.stage/'self.zip')

    def test_folder_policy_is_explicit_and_byte_counted(self):
        self.assertEqual(r.folder_policy('SampleApp')['status'],'PASS')
        self.assertEqual(r.folder_policy('A'*32)['status'],'PASS')
        for value in ['A'*33,'../bad','bad/name','bad\\name','CON','name.','тест']:
            with self.subTest(value=value),self.assertRaises(FormatError):r.folder_policy(value)


if __name__=='__main__':unittest.main()
