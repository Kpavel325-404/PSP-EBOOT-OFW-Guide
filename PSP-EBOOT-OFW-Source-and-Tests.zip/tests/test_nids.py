import importlib
import unittest
from pspguide.formats import parse_prx,FormatError
from tests.fixtures import prx

try:n=importlib.import_module('pspguide.nids')
except ModuleNotFoundError:n=None


class NidTests(unittest.TestCase):
    def setUp(self):self.assertIsNotNone(n,'pinned NID auditor implementation missing')

    def mapping(self):
        return n.map_sources({'src/display/sceDisplay.S':b'IMPORT_FUNC "sceDisplay",0x984C27E7,sceDisplayWaitVblankStart\n',
                              'src/user/Kernel_Library.S':b'IMPORT_FUNC "Kernel_Library",0xBEA46419,sceKernelLockLwMutex\nIMPORT_FUNC "Kernel_Library",0x15B6446B,sceKernelUnlockLwMutex\n'})

    def test_library_nid_pair_has_precise_sdk_only_evidence(self):
        report=n.inventory(parse_prx(prx()),self.mapping())
        self.assertEqual(report['functions'][0]['status'],'VERIFIED')
        self.assertEqual(report['functions'][0]['symbol'],'sceDisplayWaitVblankStart')
        self.assertEqual(report['firmware_exports'],'UNKNOWN')
        self.assertEqual(report['physical_OFW'],'NOT TESTED')

    def test_correct_kernel_library_mutex_names_not_old_pdf_names(self):
        table=self.mapping()['functions']
        self.assertEqual(table['Kernel_Library:BEA46419']['symbol'],'sceKernelLockLwMutex')
        self.assertEqual(table['Kernel_Library:15B6446B']['symbol'],'sceKernelUnlockLwMutex')

    def test_unknown_nid_is_unknown_not_unsupported(self):
        report=n.inventory(parse_prx(prx(nid=0xdeadbeef)),self.mapping())
        self.assertEqual(report['functions'][0]['status'],'UNKNOWN')
        with self.assertRaisesRegex(FormatError,'UNKNOWN'):n.require_user_profile(report)

    def test_different_library_cannot_borrow_the_same_nid(self):
        table=self.mapping();table['functions']['Other:DEADBEEF']={'symbol':'unrelated','file':'x.S','line':1}
        report=n.inventory(parse_prx(prx(nid=0xdeadbeef)),table)
        self.assertEqual(report['functions'][0]['status'],'UNKNOWN')

    def test_kernel_module_is_unsupported_for_this_user_profile(self):
        report=n.inventory(parse_prx(prx(attribute=0x1000)),self.mapping())
        self.assertEqual(report['module_status'],'UNSUPPORTED')
        with self.assertRaises(FormatError):n.require_user_profile(report)

    def test_driver_source_is_not_promoted_to_public_user_mapping(self):
        with self.assertRaisesRegex(FormatError,'public user source'):
            n.map_sources({'src/audio/sceAudio_driver.S':b'IMPORT_FUNC "sceAudio_driver",0x12345678,private\n'})

    def test_conflicting_mapping_is_not_silently_overwritten(self):
        with self.assertRaisesRegex(FormatError,'Conflicting'):
            n.map_sources({'src/user/a.S':b'IMPORT_FUNC "X",0x12345678,one\nIMPORT_FUNC "X",0x12345678,two\n'})


if __name__=='__main__':unittest.main()
