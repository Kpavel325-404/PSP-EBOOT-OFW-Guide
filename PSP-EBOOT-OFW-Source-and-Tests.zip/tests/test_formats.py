import importlib
import struct
import unittest
from tests.fixtures import pbp, prx, sfo

try:
    f = importlib.import_module('pspguide.formats')
except ModuleNotFoundError:
    f = None


class FormatTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(f, 'bounded formats implementation is missing')

    def test_positive_container_and_explicit_sfo_profile(self):
        p = f.parse_pbp(pbp()); values = f.parse_sfo(p.sections[0])
        f.check_sample_sfo(values)
        self.assertEqual(values['MEMSIZE'], 0)
        self.assertEqual(values['PSP_SYSTEM_VER'], '6.60')
        self.assertEqual(len(p.sections), 8)

    def test_bad_pbp_offsets_version_and_magic(self):
        for offset, value in [(0,0),(4,0x20000),(8,39),(32,0xffffffff)]:
            with self.subTest(offset=offset):
                b = bytearray(pbp()); struct.pack_into('<I',b,offset,value)
                with self.assertRaises(f.FormatError): f.parse_pbp(b)

    def test_sfo_rejects_wrong_profile_even_when_copies_match(self):
        for key, value in [('MEMSIZE',1),('PSP_SYSTEM_VER','9.99'),('BOOTABLE',0),('CATEGORY','EG'),('TITLE','Other')]:
            values = {'TITLE':'SampleApp','CATEGORY':'MG','BOOTABLE':1,'MEMSIZE':0,'PSP_SYSTEM_VER':'6.60'}
            values[key] = value
            with self.subTest(key=key), self.assertRaises(f.FormatError):
                f.check_sample_sfo(f.parse_sfo(sfo(values)))

    def test_sfo_bounds_duplicate_keys_and_string_termination(self):
        examples = []
        b=bytearray(sfo());struct.pack_into('<I',b,12,len(b)+1);examples.append(b)
        b=bytearray(sfo());struct.pack_into('<H',b,36,struct.unpack_from('<H',b,20)[0]);examples.append(b)
        b=bytearray(sfo());b[-1]=65;examples.append(b)
        for i,b in enumerate(examples):
            with self.subTest(i=i),self.assertRaises(f.FormatError):f.parse_sfo(b)

    def test_prx_module_import_and_relocation(self):
        p=f.parse_prx(prx());self.assertEqual(p.module['attribute'],0)
        self.assertEqual(p.module['name'],'SampleApp')
        self.assertEqual(p.imports[0]['library'],'sceDisplay')
        self.assertEqual(p.imports[0]['nids'],[0x984c27e7])
        fixed, count=f.adjust_relocations(p)
        self.assertEqual(count,1);self.assertNotEqual(fixed,p.data)
        self.assertEqual(f.parse_prx(fixed).relocations[0]['type'],0)

    def test_nobits_does_not_consume_file_bytes(self):
        b=bytearray(prx());table=struct.unpack_from('<I',b,32)[0]
        struct.pack_into('<I',b,table+7*40+16,0x7fffffff)
        self.assertEqual(f.parse_prx(b).module['name'],'SampleApp')

    def test_elf_header_table_and_segment_bounds(self):
        examples=[]
        for offset,fmt,value in [(16,'H',2),(18,'H',3),(28,'I',0xfffffff0),(32,'I',0xfffffff0),(42,'H',31),(44,'H',65535),(46,'H',39)]:
            b=bytearray(prx());struct.pack_into('<'+fmt,b,offset,value);examples.append(b)
        b=bytearray(prx());struct.pack_into('<I',b,52+16,len(b)+1);examples.append(b)
        b=bytearray(prx());struct.pack_into('<I',b,52+20,1);examples.append(b)
        for i,b in enumerate(examples):
            with self.subTest(i=i),self.assertRaises(f.FormatError):f.parse_prx(b)

    def test_bad_import_pointers_counts_and_unterminated_names(self):
        examples=[]
        b=bytearray(prx());struct.pack_into('<I',b,0x1a0,0xfffffff0);examples.append(b)
        b=bytearray(prx());struct.pack_into('<H',b,0x1aa,65535);examples.append(b)
        b=bytearray(prx());b[0x1a8]=4;examples.append(b)
        b=bytearray(prx());b[0x1a9]=1;examples.append(b)
        b=bytearray(prx());b[0x160:0x1c0]=b'A'*0x60;examples.append(b)
        for i,b in enumerate(examples):
            with self.subTest(i=i),self.assertRaises(f.FormatError):f.parse_prx(b)

    def test_relocation_ranges_and_segment_indices(self):
        for which,value in [(0,0xfffffffc),(1,0x0000ff02),(1,0x00ff0002),(1,0xff)]:
            b=bytearray(prx());table=struct.unpack_from('<I',b,32)[0];at=struct.unpack_from('<I',b,table+9*40+16)[0]
            struct.pack_into('<I',b,at+4*which,value)
            with self.subTest(which=which,value=value),self.assertRaises(f.FormatError):f.parse_prx(b)


if __name__=='__main__':unittest.main()
